<?php
/**
 * Template Name: Services Page
 *
 * @package RiskVerifier
 */

get_header();
?>
  <main>
    <!-- Vector Header Banner -->
    <section class="vector-header-banner">
      <!-- Left Vector Wing -->
      <div class="banner-vector-left" aria-hidden="true">
        <svg viewBox="0 0 340 160" preserveAspectRatio="none" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="cyanGradL" x1="0%" y1="0%" x2="100%" y2="80%">
              <stop offset="0%" stop-color="#00e5ff" />
              <stop offset="50%" stop-color="#00b4d8" />
              <stop offset="100%" stop-color="#0077b6" />
            </linearGradient>
            <linearGradient id="navyGradL" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#05264b" />
              <stop offset="100%" stop-color="#083d77" />
            </linearGradient>
            <filter id="vectorDropShadowL" x="-30%" y="-30%" width="160%" height="160%">
              <feDropShadow dx="5" dy="4" stdDeviation="6" flood-color="#05264b" flood-opacity="0.35" />
            </filter>
            <filter id="bevelShadowL" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="2" dy="2" stdDeviation="3" flood-color="#000000" flood-opacity="0.18" />
            </filter>
          </defs>
          <path d="M 0 28 L 95 38 L 155 160 L 0 160 Z" fill="url(#navyGradL)" />
          <path d="M 70 0 L 105 0 L 132 46 L 95 38 Z" fill="#e2e8f0" filter="url(#bevelShadowL)" />
          <path d="M 0 0 L 85 0 L 132 46 L 180 160 L 155 160 L 95 38 L 0 28 Z" fill="url(#cyanGradL)" filter="url(#vectorDropShadowL)" />
        </svg>
      </div>

      <!-- Center Text Content -->
      <div class="banner-content-box">
        <span class="banner-tagline">GLOBAL SCREENING &amp; RISK SOLUTIONS</span>
        <h1 class="banner-title">SERVICES</h1>
        <div class="banner-breadcrumb">
          <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
          <span class="sep">/</span>
          <span class="current">Services</span>
        </div>
      </div>

      <!-- Right Vector Wing -->
      <div class="banner-vector-right" aria-hidden="true">
        <svg viewBox="0 0 340 160" preserveAspectRatio="none" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="cyanGradR" x1="0%" y1="0%" x2="100%" y2="80%">
              <stop offset="0%" stop-color="#00e5ff" />
              <stop offset="50%" stop-color="#00b4d8" />
              <stop offset="100%" stop-color="#0077b6" />
            </linearGradient>
            <linearGradient id="navyGradR" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#05264b" />
              <stop offset="100%" stop-color="#083d77" />
            </linearGradient>
            <filter id="vectorDropShadowR" x="-30%" y="-30%" width="160%" height="160%">
              <feDropShadow dx="5" dy="4" stdDeviation="6" flood-color="#05264b" flood-opacity="0.35" />
            </filter>
            <filter id="bevelShadowR" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="2" dy="2" stdDeviation="3" flood-color="#000000" flood-opacity="0.18" />
            </filter>
          </defs>
          <path d="M 0 28 L 95 38 L 155 160 L 0 160 Z" fill="url(#navyGradR)" />
          <path d="M 70 0 L 105 0 L 132 46 L 95 38 Z" fill="#e2e8f0" filter="url(#bevelShadowR)" />
          <path d="M 0 0 L 85 0 L 132 46 L 180 160 L 155 160 L 95 38 L 0 28 Z" fill="url(#cyanGradR)" filter="url(#vectorDropShadowR)" />
        </svg>
      </div>
    </section>

    <!-- Services Hub Section (Favif Digital Console Layout) -->
    <section class="section section-white" id="services-hub">
      <div class="container">
        <!-- Section Header -->
        <div class="svc-header-container">
          <h2 class="svc-main-title">
            <span class="svc-title-light">OUR</span> CAPABILITIES
          </h2>
          <div class="svc-title-underline"></div>
          <p class="svc-header-desc">
            Evidence-based background screening, corporate due diligence, and risk intelligence across 100+ countries. Direct-source verified, legally compliant, and auditable.
          </p>
        </div>

        <!-- Interactive Console Layout -->
        <div class="services-console-layout">
          <!-- Left Sidebar Tabs -->
          <div class="services-console-sidebar" id="servicesConsoleSidebar">
            <button class="services-sidebar-tab active" data-target="criminal-records">
              <span class="tab-num">01</span>
              <div class="tab-text">
                <span class="tab-category">Legal Screening</span>
                <span class="tab-title">Criminal Records Check</span>
              </div>
              <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 256 256" class="tab-arrow" height="16" width="16" xmlns="http://www.w3.org/2000/svg">
                <path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"></path>
              </svg>
            </button>
            <button class="services-sidebar-tab " data-target="civil-records">
              <span class="tab-num">02</span>
              <div class="tab-text">
                <span class="tab-category">Legal Screening</span>
                <span class="tab-title">Civil Records Search</span>
              </div>
              <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 256 256" class="tab-arrow" height="16" width="16" xmlns="http://www.w3.org/2000/svg">
                <path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"></path>
              </svg>
            </button>
            <button class="services-sidebar-tab " data-target="credit-finance">
              <span class="tab-num">03</span>
              <div class="tab-text">
                <span class="tab-category">Financial Risk</span>
                <span class="tab-title">Credit & Finance Reports</span>
              </div>
              <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 256 256" class="tab-arrow" height="16" width="16" xmlns="http://www.w3.org/2000/svg">
                <path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"></path>
              </svg>
            </button>
            <button class="services-sidebar-tab " data-target="vital-records">
              <span class="tab-num">04</span>
              <div class="tab-text">
                <span class="tab-category">Identity Records</span>
                <span class="tab-title">Vital Records Verification</span>
              </div>
              <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 256 256" class="tab-arrow" height="16" width="16" xmlns="http://www.w3.org/2000/svg">
                <path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"></path>
              </svg>
            </button>
            <button class="services-sidebar-tab " data-target="identity-credentials">
              <span class="tab-num">05</span>
              <div class="tab-text">
                <span class="tab-category">Identity & Credentials</span>
                <span class="tab-title">Identity & Credentials Verification</span>
              </div>
              <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 256 256" class="tab-arrow" height="16" width="16" xmlns="http://www.w3.org/2000/svg">
                <path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"></path>
              </svg>
            </button>
            <button class="services-sidebar-tab " data-target="property-asset">
              <span class="tab-num">06</span>
              <div class="tab-text">
                <span class="tab-category">Asset Intelligence</span>
                <span class="tab-title">Property & Asset Searches</span>
              </div>
              <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 256 256" class="tab-arrow" height="16" width="16" xmlns="http://www.w3.org/2000/svg">
                <path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"></path>
              </svg>
            </button>
            <button class="services-sidebar-tab " data-target="driving-records">
              <span class="tab-num">07</span>
              <div class="tab-text">
                <span class="tab-category">Motor Vehicle Records</span>
                <span class="tab-title">Driving & Motor Vehicle Records (MVR)</span>
              </div>
              <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 256 256" class="tab-arrow" height="16" width="16" xmlns="http://www.w3.org/2000/svg">
                <path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"></path>
              </svg>
            </button>
            <button class="services-sidebar-tab " data-target="verifications-references">
              <span class="tab-num">08</span>
              <div class="tab-text">
                <span class="tab-category">HR & Employment</span>
                <span class="tab-title">Verifications & References</span>
              </div>
              <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 256 256" class="tab-arrow" height="16" width="16" xmlns="http://www.w3.org/2000/svg">
                <path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"></path>
              </svg>
            </button>
            <button class="services-sidebar-tab " data-target="due-diligence">
              <span class="tab-num">09</span>
              <div class="tab-text">
                <span class="tab-category">Corporate Intelligence</span>
                <span class="tab-title">Due Diligence & Sanctions Screening</span>
              </div>
              <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 256 256" class="tab-arrow" height="16" width="16" xmlns="http://www.w3.org/2000/svg">
                <path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"></path>
              </svg>
            </button>
            <button class="services-sidebar-tab " data-target="media-analytics">
              <span class="tab-num">10</span>
              <div class="tab-text">
                <span class="tab-category">Risk Intelligence</span>
                <span class="tab-title">Media Analytics</span>
              </div>
              <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 256 256" class="tab-arrow" height="16" width="16" xmlns="http://www.w3.org/2000/svg">
                <path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"></path>
              </svg>
            </button>
            <button class="services-sidebar-tab " data-target="bespoke-research">
              <span class="tab-num">11</span>
              <div class="tab-text">
                <span class="tab-category">Custom Intelligence</span>
                <span class="tab-title">Bespoke Research</span>
              </div>
              <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 256 256" class="tab-arrow" height="16" width="16" xmlns="http://www.w3.org/2000/svg">
                <path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"></path>
              </svg>
            </button>
            <button class="services-sidebar-tab " data-target="geopolitical-advisory">
              <span class="tab-num">12</span>
              <div class="tab-text">
                <span class="tab-category">Strategic Advisory</span>
                <span class="tab-title">Geopolitical Advisory</span>
              </div>
              <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 256 256" class="tab-arrow" height="16" width="16" xmlns="http://www.w3.org/2000/svg">
                <path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"></path>
              </svg>
            </button>
          </div>

          <!-- Right Showcase Panes -->
          <div class="services-console-showcase" id="servicesConsoleShowcase">
          <!-- Showcase Pane: Criminal Records Check -->
          <div class="service-showcase-pane" id="showcase-criminal-records" style="display: block;">
            <div class="showcase-header-row">
              <div class="showcase-icon-badge">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/criminal-record-check.png" alt="Criminal Records Check">
              </div>
              <div class="showcase-title-area">
                <span class="showcase-category-pill">Legal Screening</span>
                <h2 class="showcase-title">Criminal Records Check</h2>
              </div>
              <span class="showcase-turnaround-badge">⚡ SLA: 24–72 Hours</span>
            </div>

            <p class="showcase-desc">Conduct comprehensive criminal background checks across multiple jurisdictions to ensure safe hiring, regulatory compliance, and risk mitigation.</p>

            <div class="showcase-tags-cloud">
              <span class="showcase-tag-pill">Police Archives</span><span class="showcase-tag-pill">Court Registries</span><span class="showcase-tag-pill">FCRA Compliant</span><span class="showcase-tag-pill">GDPR Ready</span>
            </div>

            <h3 class="showcase-section-heading">Core Areas of Verification</h3>
            <div class="showcase-subservices-grid">
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/criminal-record-check.png" alt="Police Clearance Records" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Police Clearance Records</h4>
                    <p class="sub-card-desc">Searches across municipal, state, and federal law enforcement databases for arrests and dispositions.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/civil-record-check.png" alt="Court Docket Searches" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Court Docket Searches</h4>
                    <p class="sub-card-desc">Direct verification of felony, misdemeanor, and active warrant court dockets across authorized registries.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/due-diligence.png" alt="National & Global Registries" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">National & Global Registries</h4>
                    <p class="sub-card-desc">Cross-referencing national criminal indexes and international police cooperation archives.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/identity-check.png" alt="Certificate Authentication" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Certificate Authentication</h4>
                    <p class="sub-card-desc">Validation of government-issued police character certificates and apostille seals against issuing authorities.</p>
                  </div>
                </div>
            </div>

            <h3 class="showcase-section-heading">Key Verification Deliverables</h3>
            <ul class="showcase-features-list">
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Evidentiary summary with official court case docket numbers</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Verification timestamps directly recorded from police bureaus</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Objective risk severity index (Clear / Record Found)</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Strict adherence to FCRA adverse-action guidance and GDPR protocols</span>
                </li>
            </ul>

            <div class="showcase-actions">
              <a href="index.html#quote-form-section" class="btn btn-primary btn-md">
                Request This Verification Check
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"></path><polyline points="12 5 19 12 12 19"></polyline></svg>
              </a>
              <button class="btn btn-secondary btn-md" onclick="openServiceModal('criminal-records')">
                Quick Summary &amp; Scope
              </button>
              <a href="https://wa.me/13862431035?text=Hello%20Risk%20Verifier%2C%20I%20would%20like%20to%20inquire%20about%20Criminal Records Check" target="_blank" class="btn btn-outline btn-md" style="border-color:#083d77; color:#083d77;">
                Direct WhatsApp Inquiry
              </a>
            </div>
          </div>
          <!-- Showcase Pane: Civil Records Search -->
          <div class="service-showcase-pane" id="showcase-civil-records" style="display: none;">
            <div class="showcase-header-row">
              <div class="showcase-icon-badge">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/civil-record-check.png" alt="Civil Records Search">
              </div>
              <div class="showcase-title-area">
                <span class="showcase-category-pill">Legal Screening</span>
                <h2 class="showcase-title">Civil Records Search</h2>
              </div>
              <span class="showcase-turnaround-badge">⚡ SLA: 24–48 Hours</span>
            </div>

            <p class="showcase-desc">Access civil litigation records, court filings, bankruptcies, and commercial legal disputes to uncover hidden liabilities associated with individuals or firms.</p>

            <div class="showcase-tags-cloud">
              <span class="showcase-tag-pill">Superior Courts</span><span class="showcase-tag-pill">Commercial Disputes</span><span class="showcase-tag-pill">Bankruptcies</span><span class="showcase-tag-pill">Contractual Claims</span>
            </div>

            <h3 class="showcase-section-heading">Core Areas of Verification</h3>
            <div class="showcase-subservices-grid">
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/civil-record-check.png" alt="Commercial Litigation" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Commercial Litigation</h4>
                    <p class="sub-card-desc">Identification of active and historical contract disputes, breach of fiduciary duty, and corporate litigation.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/credit-record-check.png" alt="Judgments & Liens" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Judgments & Liens</h4>
                    <p class="sub-card-desc">Cross-referencing tax liens, monetary judgments, foreclosures, and enforceable legal debts.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/property-record-check.png" alt="Bankruptcy Records" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Bankruptcy Records</h4>
                    <p class="sub-card-desc">Comprehensive insolvency court record checks across regional and national bankruptcy registries.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/reference-check.png" alt="Dispute Resolution History" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Dispute Resolution History</h4>
                    <p class="sub-card-desc">Tracking arbitration awards, settlement records, and tribunal determinations across jurisdictions.</p>
                  </div>
                </div>
            </div>

            <h3 class="showcase-section-heading">Key Verification Deliverables</h3>
            <ul class="showcase-features-list">
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Plaintiff / defendant cross-party litigation search report</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Docket filings, claim amounts, and ultimate judgment dispositions</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Analysis of commercial reliability and dispute risk rating</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Complete jurisdiction indexing across superior and appellate courts</span>
                </li>
            </ul>

            <div class="showcase-actions">
              <a href="index.html#quote-form-section" class="btn btn-primary btn-md">
                Request This Verification Check
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"></path><polyline points="12 5 19 12 12 19"></polyline></svg>
              </a>
              <button class="btn btn-secondary btn-md" onclick="openServiceModal('civil-records')">
                Quick Summary &amp; Scope
              </button>
              <a href="https://wa.me/13862431035?text=Hello%20Risk%20Verifier%2C%20I%20would%20like%20to%20inquire%20about%20Civil Records Search" target="_blank" class="btn btn-outline btn-md" style="border-color:#083d77; color:#083d77;">
                Direct WhatsApp Inquiry
              </a>
            </div>
          </div>
          <!-- Showcase Pane: Credit & Finance Reports -->
          <div class="service-showcase-pane" id="showcase-credit-finance" style="display: none;">
            <div class="showcase-header-row">
              <div class="showcase-icon-badge">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/credit-record-check.png" alt="Credit & Finance Reports">
              </div>
              <div class="showcase-title-area">
                <span class="showcase-category-pill">Financial Risk</span>
                <h2 class="showcase-title">Credit & Finance Reports</h2>
              </div>
              <span class="showcase-turnaround-badge">⚡ SLA: 24–48 Hours</span>
            </div>

            <p class="showcase-desc">Gain deep insights into financial behavior with individual and corporate credit reports to evaluate fiscal stability and fraud exposure.</p>

            <div class="showcase-tags-cloud">
              <span class="showcase-tag-pill">Credit Bureau</span><span class="showcase-tag-pill">Solvency Rating</span><span class="showcase-tag-pill">Debt Obligations</span><span class="showcase-tag-pill">Corporate Solvency</span>
            </div>

            <h3 class="showcase-section-heading">Core Areas of Verification</h3>
            <div class="showcase-subservices-grid">
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/credit-record-check.png" alt="Credit Bureau Profile" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Credit Bureau Profile</h4>
                    <p class="sub-card-desc">Authorized retrieval of official credit bureau scores, payment histories, and historical delinquent accounts.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/property-record-check.png" alt="Corporate Financial Health" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Corporate Financial Health</h4>
                    <p class="sub-card-desc">Assessment of balance sheet filings, solvency ratings, debt ratios, and company creditworthiness.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/civil-record-check.png" alt="Public Financial Records" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Public Financial Records</h4>
                    <p class="sub-card-desc">Tracking unsatisfied judgments, tax collection notices, and public commercial default filings.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/due-diligence.png" alt="Financial Authority Inquiries" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Financial Authority Inquiries</h4>
                    <p class="sub-card-desc">Verification with central banks, securities commissions, and financial conduct authorities.</p>
                  </div>
                </div>
            </div>

            <h3 class="showcase-section-heading">Key Verification Deliverables</h3>
            <ul class="showcase-features-list">
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Official credit bureau score breakdown and risk grade</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>36-month repayment track record and debt utilization ratio</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Independent assessment of fiscal stability and fraud vulnerability</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Compliant with local credit reporting authorization laws</span>
                </li>
            </ul>

            <div class="showcase-actions">
              <a href="index.html#quote-form-section" class="btn btn-primary btn-md">
                Request This Verification Check
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"></path><polyline points="12 5 19 12 12 19"></polyline></svg>
              </a>
              <button class="btn btn-secondary btn-md" onclick="openServiceModal('credit-finance')">
                Quick Summary &amp; Scope
              </button>
              <a href="https://wa.me/13862431035?text=Hello%20Risk%20Verifier%2C%20I%20would%20like%20to%20inquire%20about%20Credit & Finance Reports" target="_blank" class="btn btn-outline btn-md" style="border-color:#083d77; color:#083d77;">
                Direct WhatsApp Inquiry
              </a>
            </div>
          </div>
          <!-- Showcase Pane: Vital Records Verification -->
          <div class="service-showcase-pane" id="showcase-vital-records" style="display: none;">
            <div class="showcase-header-row">
              <div class="showcase-icon-badge">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/vital-record-check.png" alt="Vital Records Verification">
              </div>
              <div class="showcase-title-area">
                <span class="showcase-category-pill">Identity Records</span>
                <h2 class="showcase-title">Vital Records Verification</h2>
              </div>
              <span class="showcase-turnaround-badge">⚡ SLA: 2–5 Business Days</span>
            </div>

            <p class="showcase-desc">Verify essential registry records including birth certificates, marital status, and government death records for conclusive identity confirmation.</p>

            <div class="showcase-tags-cloud">
              <span class="showcase-tag-pill">Civil Registry</span><span class="showcase-tag-pill">Birth Certificates</span><span class="showcase-tag-pill">Marital Records</span><span class="showcase-tag-pill">Apostille Authentication</span>
            </div>

            <h3 class="showcase-section-heading">Core Areas of Verification</h3>
            <div class="showcase-subservices-grid">
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/vital-record-check.png" alt="Birth Registry Inquiries" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Birth Registry Inquiries</h4>
                    <p class="sub-card-desc">Direct validation against municipal and national civil status registries to verify origin records.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/reference-check.png" alt="Marital Status Validation" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Marital Status Validation</h4>
                    <p class="sub-card-desc">Verification of marriage registrations, civil partnership records, and legal dissolutions.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/identity-check.png" alt="Official Death Master Files" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Official Death Master Files</h4>
                    <p class="sub-card-desc">Cross-referencing government vital status archives to protect against deceased identity theft.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/geopolitical-advisory.png" alt="Consular & Apostille Checks" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Consular & Apostille Checks</h4>
                    <p class="sub-card-desc">Verification of consular legalizations, apostille certificates, and international diplomatic seals.</p>
                  </div>
                </div>
            </div>

            <h3 class="showcase-section-heading">Key Verification Deliverables</h3>
            <ul class="showcase-features-list">
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Certified confirmation from primary government civil registry</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Verification of official serial numbers, watermarks, and security seals</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Definitive identity lineage and vital status confirmation</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>International multi-language translation and evidentiary support</span>
                </li>
            </ul>

            <div class="showcase-actions">
              <a href="index.html#quote-form-section" class="btn btn-primary btn-md">
                Request This Verification Check
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"></path><polyline points="12 5 19 12 12 19"></polyline></svg>
              </a>
              <button class="btn btn-secondary btn-md" onclick="openServiceModal('vital-records')">
                Quick Summary &amp; Scope
              </button>
              <a href="https://wa.me/13862431035?text=Hello%20Risk%20Verifier%2C%20I%20would%20like%20to%20inquire%20about%20Vital Records Verification" target="_blank" class="btn btn-outline btn-md" style="border-color:#083d77; color:#083d77;">
                Direct WhatsApp Inquiry
              </a>
            </div>
          </div>
          <!-- Showcase Pane: Identity & Credentials Verification -->
          <div class="service-showcase-pane" id="showcase-identity-credentials" style="display: none;">
            <div class="showcase-header-row">
              <div class="showcase-icon-badge">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/identity-check.png" alt="Identity & Credentials Verification">
              </div>
              <div class="showcase-title-area">
                <span class="showcase-category-pill">Identity & Credentials</span>
                <h2 class="showcase-title">Identity & Credentials Verification</h2>
              </div>
              <span class="showcase-turnaround-badge">⚡ SLA: 24–48 Hours</span>
            </div>

            <p class="showcase-desc">Authenticate government-issued IDs, academic degrees, and professional licensing to eliminate resume fraud and identity theft.</p>

            <div class="showcase-tags-cloud">
              <span class="showcase-tag-pill">Passport MRZ</span><span class="showcase-tag-pill">Registrar Degree Check</span><span class="showcase-tag-pill">Professional Licenses</span><span class="showcase-tag-pill">Biometric Validation</span>
            </div>

            <h3 class="showcase-section-heading">Core Areas of Verification</h3>
            <div class="showcase-subservices-grid">
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/identity-check.png" alt="Government ID Verification" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Government ID Verification</h4>
                    <p class="sub-card-desc">Verification of passports, National ID cards, and work permits via official issuing database registries.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/reference-check.png" alt="Academic Degree Authentication" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Academic Degree Authentication</h4>
                    <p class="sub-card-desc">Direct contact with university registrar offices to verify degree title, major, honors, and graduation date.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/civil-record-check.png" alt="Professional License Status" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Professional License Status</h4>
                    <p class="sub-card-desc">Querying bar associations, medical councils, accounting institutes, and engineering boards.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/due-diligence.png" alt="Tamper & Forgery Detection" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Tamper & Forgery Detection</h4>
                    <p class="sub-card-desc">Forensic inspection of micro-printing, MRZ optical barcodes, security fibers, and holograms.</p>
                  </div>
                </div>
            </div>

            <h3 class="showcase-section-heading">Key Verification Deliverables</h3>
            <ul class="showcase-features-list">
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Direct registrar verification letters with institution seals</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Comprehensive credential validation matching resume representations</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Biometric document liveness and validity confirmation</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Zero tolerance detection of diploma mills and fraudulent credentials</span>
                </li>
            </ul>

            <div class="showcase-actions">
              <a href="index.html#quote-form-section" class="btn btn-primary btn-md">
                Request This Verification Check
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"></path><polyline points="12 5 19 12 12 19"></polyline></svg>
              </a>
              <button class="btn btn-secondary btn-md" onclick="openServiceModal('identity-credentials')">
                Quick Summary &amp; Scope
              </button>
              <a href="https://wa.me/13862431035?text=Hello%20Risk%20Verifier%2C%20I%20would%20like%20to%20inquire%20about%20Identity & Credentials Verification" target="_blank" class="btn btn-outline btn-md" style="border-color:#083d77; color:#083d77;">
                Direct WhatsApp Inquiry
              </a>
            </div>
          </div>
          <!-- Showcase Pane: Property & Asset Searches -->
          <div class="service-showcase-pane" id="showcase-property-asset" style="display: none;">
            <div class="showcase-header-row">
              <div class="showcase-icon-badge">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/property-record-check.png" alt="Property & Asset Searches">
              </div>
              <div class="showcase-title-area">
                <span class="showcase-category-pill">Asset Intelligence</span>
                <h2 class="showcase-title">Property & Asset Searches</h2>
              </div>
              <span class="showcase-turnaround-badge">⚡ SLA: 2–4 Business Days</span>
            </div>

            <p class="showcase-desc">Identify real estate deeds, corporate asset registrations, and vehicle ownership to evaluate financial strength and uncover hidden assets.</p>

            <div class="showcase-tags-cloud">
              <span class="showcase-tag-pill">Cadastral Registries</span><span class="showcase-tag-pill">Commercial Assets</span><span class="showcase-tag-pill">Encumbrances</span><span class="showcase-tag-pill">Beneficial Ownership</span>
            </div>

            <h3 class="showcase-section-heading">Core Areas of Verification</h3>
            <div class="showcase-subservices-grid">
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/property-record-check.png" alt="Land & Real Estate Title" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Land & Real Estate Title</h4>
                    <p class="sub-card-desc">Querying cadastral registries and county deed offices for residential and commercial parcels.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/credit-record-check.png" alt="Corporate Asset Holdings" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Corporate Asset Holdings</h4>
                    <p class="sub-card-desc">Investigation of plant, machinery, heavy equipment, and commercial vehicle fleet ownership.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/civil-record-check.png" alt="Encumbrance & Mortgage Search" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Encumbrance & Mortgage Search</h4>
                    <p class="sub-card-desc">Mapping outstanding mortgages, secondary liens, and municipal tax encumbrances on assets.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/due-diligence.png" alt="Beneficial Asset Mapping" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Beneficial Asset Mapping</h4>
                    <p class="sub-card-desc">Unraveling holding companies, family trusts, and offshore entities concealing asset ownership.</p>
                  </div>
                </div>
            </div>

            <h3 class="showcase-section-heading">Key Verification Deliverables</h3>
            <ul class="showcase-features-list">
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Cadastral property parcel ownership deeds and transaction valuations</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Comprehensive lien and mortgage liability breakdown</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Asset trace profile across multiple domestic and offshore jurisdictions</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Independent verification of collateral for commercial transactions</span>
                </li>
            </ul>

            <div class="showcase-actions">
              <a href="index.html#quote-form-section" class="btn btn-primary btn-md">
                Request This Verification Check
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"></path><polyline points="12 5 19 12 12 19"></polyline></svg>
              </a>
              <button class="btn btn-secondary btn-md" onclick="openServiceModal('property-asset')">
                Quick Summary &amp; Scope
              </button>
              <a href="https://wa.me/13862431035?text=Hello%20Risk%20Verifier%2C%20I%20would%20like%20to%20inquire%20about%20Property & Asset Searches" target="_blank" class="btn btn-outline btn-md" style="border-color:#083d77; color:#083d77;">
                Direct WhatsApp Inquiry
              </a>
            </div>
          </div>
          <!-- Showcase Pane: Driving & Motor Vehicle Records (MVR) -->
          <div class="service-showcase-pane" id="showcase-driving-records" style="display: none;">
            <div class="showcase-header-row">
              <div class="showcase-icon-badge">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/driving-record-check.png" alt="Driving & Motor Vehicle Records (MVR)">
              </div>
              <div class="showcase-title-area">
                <span class="showcase-category-pill">Motor Vehicle Records</span>
                <h2 class="showcase-title">Driving & Motor Vehicle Records (MVR)</h2>
              </div>
              <span class="showcase-turnaround-badge">⚡ SLA: 24–48 Hours</span>
            </div>

            <p class="showcase-desc">Verify driver history, license validity, suspension orders, and moving violations to protect fleet operations and workplace safety.</p>

            <div class="showcase-tags-cloud">
              <span class="showcase-tag-pill">DMV Records</span><span class="showcase-tag-pill">CDL Endorsements</span><span class="showcase-tag-pill">Traffic Violations</span><span class="showcase-tag-pill">Fleet Compliance</span>
            </div>

            <h3 class="showcase-section-heading">Core Areas of Verification</h3>
            <div class="showcase-subservices-grid">
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/driving-record-check.png" alt="Driver License Status" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Driver License Status</h4>
                    <p class="sub-card-desc">Real-time verification of driver license validity, expiration, class, and jurisdictional jurisdiction.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/civil-record-check.png" alt="Violation & Infraction Record" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Violation & Infraction Record</h4>
                    <p class="sub-card-desc">Extracting moving violations, speeding citations, points balance, and reckless driving citations.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/criminal-record-check.png" alt="Suspension & Revocation History" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Suspension & Revocation History</h4>
                    <p class="sub-card-desc">Identification of past or active DUI / DWI offenses, mandatory court suspensions, and revocations.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/identity-check.png" alt="Commercial CDL Endorsements" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Commercial CDL Endorsements</h4>
                    <p class="sub-card-desc">Verification of hazmat, passenger, tanker, and double-trailer commercial endorsements.</p>
                  </div>
                </div>
            </div>

            <h3 class="showcase-section-heading">Key Verification Deliverables</h3>
            <ul class="showcase-features-list">
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Official DMV motor vehicle record printout and status code</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>3-to-7 year traffic violation history and penalty points balance</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Fleet insurance eligibility and liability risk classification</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Automated annual re-screening schedule for enterprise fleets</span>
                </li>
            </ul>

            <div class="showcase-actions">
              <a href="index.html#quote-form-section" class="btn btn-primary btn-md">
                Request This Verification Check
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"></path><polyline points="12 5 19 12 12 19"></polyline></svg>
              </a>
              <button class="btn btn-secondary btn-md" onclick="openServiceModal('driving-records')">
                Quick Summary &amp; Scope
              </button>
              <a href="https://wa.me/13862431035?text=Hello%20Risk%20Verifier%2C%20I%20would%20like%20to%20inquire%20about%20Driving & Motor Vehicle Records (MVR)" target="_blank" class="btn btn-outline btn-md" style="border-color:#083d77; color:#083d77;">
                Direct WhatsApp Inquiry
              </a>
            </div>
          </div>
          <!-- Showcase Pane: Verifications & References -->
          <div class="service-showcase-pane" id="showcase-verifications-references" style="display: none;">
            <div class="showcase-header-row">
              <div class="showcase-icon-badge">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/reference-check.png" alt="Verifications & References">
              </div>
              <div class="showcase-title-area">
                <span class="showcase-category-pill">HR & Employment</span>
                <h2 class="showcase-title">Verifications & References</h2>
              </div>
              <span class="showcase-turnaround-badge">⚡ SLA: 2–4 Business Days</span>
            </div>

            <p class="showcase-desc">Structured verification of past employment history, job titles, responsibilities, tenure, and professional supervisor references.</p>

            <div class="showcase-tags-cloud">
              <span class="showcase-tag-pill">Employment Dates</span><span class="showcase-tag-pill">Title Authentication</span><span class="showcase-tag-pill">Rehire Eligibility</span><span class="showcase-tag-pill">Supervisor Interviews</span>
            </div>

            <h3 class="showcase-section-heading">Core Areas of Verification</h3>
            <div class="showcase-subservices-grid">
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/reference-check.png" alt="Employment Tenure Verification" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Employment Tenure Verification</h4>
                    <p class="sub-card-desc">Direct HR registry contact to verify start/end dates, full-time/part-time status, and job titles.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/identity-check.png" alt="Separation Reason & Rehire" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Separation Reason & Rehire</h4>
                    <p class="sub-card-desc">Confirmation of voluntary/involuntary termination and formal eligibility for rehire status.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/civil-record-check.png" alt="In-Depth Supervisor Interviews" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">In-Depth Supervisor Interviews</h4>
                    <p class="sub-card-desc">Structured telephone interviews with direct line managers evaluating work performance and integrity.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/due-diligence.png" alt="Peer & Competency Reviews" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Peer & Competency Reviews</h4>
                    <p class="sub-card-desc">360-degree professional peer evaluations assessing leadership, technical skills, and ethics.</p>
                  </div>
                </div>
            </div>

            <h3 class="showcase-section-heading">Key Verification Deliverables</h3>
            <ul class="showcase-features-list">
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Detailed corporate HR verification records with corporate stamps</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Transcribed supervisor reference interview notes and performance scoring</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Discrepancy flag analysis comparing candidate resumes with official records</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Standardized objective evaluation report conforming to privacy statutes</span>
                </li>
            </ul>

            <div class="showcase-actions">
              <a href="index.html#quote-form-section" class="btn btn-primary btn-md">
                Request This Verification Check
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"></path><polyline points="12 5 19 12 12 19"></polyline></svg>
              </a>
              <button class="btn btn-secondary btn-md" onclick="openServiceModal('verifications-references')">
                Quick Summary &amp; Scope
              </button>
              <a href="https://wa.me/13862431035?text=Hello%20Risk%20Verifier%2C%20I%20would%20like%20to%20inquire%20about%20Verifications & References" target="_blank" class="btn btn-outline btn-md" style="border-color:#083d77; color:#083d77;">
                Direct WhatsApp Inquiry
              </a>
            </div>
          </div>
          <!-- Showcase Pane: Due Diligence & Sanctions Screening -->
          <div class="service-showcase-pane" id="showcase-due-diligence" style="display: none;">
            <div class="showcase-header-row">
              <div class="showcase-icon-badge">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/due-diligence.png" alt="Due Diligence & Sanctions Screening">
              </div>
              <div class="showcase-title-area">
                <span class="showcase-category-pill">Corporate Intelligence</span>
                <h2 class="showcase-title">Due Diligence & Sanctions Screening</h2>
              </div>
              <span class="showcase-turnaround-badge">⚡ SLA: 3–5 Business Days</span>
            </div>

            <p class="showcase-desc">Analyze executive and corporate profiles against international sanctions, PEP lists, watchlists, and adverse intelligence.</p>

            <div class="showcase-tags-cloud">
              <span class="showcase-tag-pill">OFAC Sanctions</span><span class="showcase-tag-pill">PEP Screening</span><span class="showcase-tag-pill">Adverse Media</span><span class="showcase-tag-pill">UBO Identification</span>
            </div>

            <h3 class="showcase-section-heading">Core Areas of Verification</h3>
            <div class="showcase-subservices-grid">
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/due-diligence.png" alt="Global Sanctions Watchlists" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Global Sanctions Watchlists</h4>
                    <p class="sub-card-desc">Screening across OFAC, UN Security Council, EU Consolidated, UK HMT, and Interpol lists.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/geopolitical-advisory.png" alt="Politically Exposed Persons (PEP)" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Politically Exposed Persons (PEP)</h4>
                    <p class="sub-card-desc">Identification of senior political figures, military officers, state enterprise executives, and associates.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/property-record-check.png" alt="Ultimate Beneficial Ownership (UBO)" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Ultimate Beneficial Ownership (UBO)</h4>
                    <p class="sub-card-desc">Piercing complex multi-tier offshore holding structures to identify true individual owners.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/civil-record-check.png" alt="Bribery & FCPA Compliance" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Bribery & FCPA Compliance</h4>
                    <p class="sub-card-desc">Reviewing regulatory disciplinary enforcement, anti-money laundering (AML) alerts, and fraud databases.</p>
                  </div>
                </div>
            </div>

            <h3 class="showcase-section-heading">Key Verification Deliverables</h3>
            <ul class="showcase-features-list">
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Comprehensive sanctions and PEP match matrix with false-positive elimination</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Multi-tiered corporate ownership diagram and shareholder hierarchy</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Adverse regulatory, compliance, and international law enforcement profile</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Risk rating advisory summary for executive investment committees</span>
                </li>
            </ul>

            <div class="showcase-actions">
              <a href="index.html#quote-form-section" class="btn btn-primary btn-md">
                Request This Verification Check
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"></path><polyline points="12 5 19 12 12 19"></polyline></svg>
              </a>
              <button class="btn btn-secondary btn-md" onclick="openServiceModal('due-diligence')">
                Quick Summary &amp; Scope
              </button>
              <a href="https://wa.me/13862431035?text=Hello%20Risk%20Verifier%2C%20I%20would%20like%20to%20inquire%20about%20Due Diligence & Sanctions Screening" target="_blank" class="btn btn-outline btn-md" style="border-color:#083d77; color:#083d77;">
                Direct WhatsApp Inquiry
              </a>
            </div>
          </div>
          <!-- Showcase Pane: Media Analytics -->
          <div class="service-showcase-pane" id="showcase-media-analytics" style="display: none;">
            <div class="showcase-header-row">
              <div class="showcase-icon-badge">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/media-analytics.png" alt="Media Analytics">
              </div>
              <div class="showcase-title-area">
                <span class="showcase-category-pill">Risk Intelligence</span>
                <h2 class="showcase-title">Media Analytics</h2>
              </div>
              <span class="showcase-turnaround-badge">⚡ SLA: 2–4 Business Days</span>
            </div>

            <p class="showcase-desc">Monitor, scrape, and analyze digital news, regulatory alerts, social channels, and media exposure to safeguard brand reputation.</p>

            <div class="showcase-tags-cloud">
              <span class="showcase-tag-pill">Adverse Press</span><span class="showcase-tag-pill">Sentiment Scoring</span><span class="showcase-tag-pill">Regulatory Bulletins</span><span class="showcase-tag-pill">Reputational Risk</span>
            </div>

            <h3 class="showcase-section-heading">Core Areas of Verification</h3>
            <div class="showcase-subservices-grid">
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/media-analytics.png" alt="Global News Archive Scrapes" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Global News Archive Scrapes</h4>
                    <p class="sub-card-desc">Searching across 10,000+ local, national, and international newspapers and financial journals.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/civil-record-check.png" alt="Regulatory Gazette Tracking" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Regulatory Gazette Tracking</h4>
                    <p class="sub-card-desc">Monitoring gazette notices, trade commission alerts, and regulatory disciplinary proceedings.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/identity-check.png" alt="Digital Footprint & Social Risk" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Digital Footprint & Social Risk</h4>
                    <p class="sub-card-desc">Auditing public social media profiles, domain ownership, and online controversy signals.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/due-diligence.png" alt="Reputational Sentiment Analysis" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Reputational Sentiment Analysis</h4>
                    <p class="sub-card-desc">AI-assisted sentiment evaluation calculating negative exposure ratios and trend vectors.</p>
                  </div>
                </div>
            </div>

            <h3 class="showcase-section-heading">Key Verification Deliverables</h3>
            <ul class="showcase-features-list">
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Chronological media exposure dossier highlighting adverse stories</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Direct citations and archived copies of deleted or paywalled news articles</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Reputational risk index and stakeholder perception assessment</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Continuous automated monitoring options for high-profile personnel</span>
                </li>
            </ul>

            <div class="showcase-actions">
              <a href="index.html#quote-form-section" class="btn btn-primary btn-md">
                Request This Verification Check
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"></path><polyline points="12 5 19 12 12 19"></polyline></svg>
              </a>
              <button class="btn btn-secondary btn-md" onclick="openServiceModal('media-analytics')">
                Quick Summary &amp; Scope
              </button>
              <a href="https://wa.me/13862431035?text=Hello%20Risk%20Verifier%2C%20I%20would%20like%20to%20inquire%20about%20Media Analytics" target="_blank" class="btn btn-outline btn-md" style="border-color:#083d77; color:#083d77;">
                Direct WhatsApp Inquiry
              </a>
            </div>
          </div>
          <!-- Showcase Pane: Bespoke Research -->
          <div class="service-showcase-pane" id="showcase-bespoke-research" style="display: none;">
            <div class="showcase-header-row">
              <div class="showcase-icon-badge">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/bespoke-research.png" alt="Bespoke Research">
              </div>
              <div class="showcase-title-area">
                <span class="showcase-category-pill">Custom Intelligence</span>
                <h2 class="showcase-title">Bespoke Research</h2>
              </div>
              <span class="showcase-turnaround-badge">⚡ SLA: Tailored Scope</span>
            </div>

            <p class="showcase-desc">Tailored, customized intelligence reports designed around specific corporate M&A transactions, executive vetting, and unique needs.</p>

            <div class="showcase-tags-cloud">
              <span class="showcase-tag-pill">Cross-Border M&A</span><span class="showcase-tag-pill">OSINT Investigation</span><span class="showcase-tag-pill">Counterparty Profile</span><span class="showcase-tag-pill">Senior Executive Vetting</span>
            </div>

            <h3 class="showcase-section-heading">Core Areas of Verification</h3>
            <div class="showcase-subservices-grid">
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/bespoke-research.png" alt="Cross-Border M&A Due Diligence" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Cross-Border M&A Due Diligence</h4>
                    <p class="sub-card-desc">Bespoke investigation of acquisition targets, joint-venture partners, and local representatives.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/due-diligence.png" alt="Deep-Web OSINT Intelligence" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Deep-Web OSINT Intelligence</h4>
                    <p class="sub-card-desc">Advanced open-source intelligence gathering across unindexed databases and public repositories.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/civil-record-check.png" alt="Counterparty Integrity Profiling" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Counterparty Integrity Profiling</h4>
                    <p class="sub-card-desc">Discrete assessment of counterparty integrity, commercial track record, and operational reality.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/reference-check.png" alt="High-Stakes Executive Vetting" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">High-Stakes Executive Vetting</h4>
                    <p class="sub-card-desc">Comprehensive 360-degree investigation of prospective C-suite officers and board members.</p>
                  </div>
                </div>
            </div>

            <h3 class="showcase-section-heading">Key Verification Deliverables</h3>
            <ul class="showcase-features-list">
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Fully customized investigative brief prepared by senior forensic intelligence analysts</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Primary evidentiary exhibits, registered documents, and verified factual corroborations</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Unbiased, objective risk analysis highlighting deal-breaking red flags</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Executive briefing presentation ready for board and audit committee review</span>
                </li>
            </ul>

            <div class="showcase-actions">
              <a href="index.html#quote-form-section" class="btn btn-primary btn-md">
                Request This Verification Check
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"></path><polyline points="12 5 19 12 12 19"></polyline></svg>
              </a>
              <button class="btn btn-secondary btn-md" onclick="openServiceModal('bespoke-research')">
                Quick Summary &amp; Scope
              </button>
              <a href="https://wa.me/13862431035?text=Hello%20Risk%20Verifier%2C%20I%20would%20like%20to%20inquire%20about%20Bespoke Research" target="_blank" class="btn btn-outline btn-md" style="border-color:#083d77; color:#083d77;">
                Direct WhatsApp Inquiry
              </a>
            </div>
          </div>
          <!-- Showcase Pane: Geopolitical Advisory -->
          <div class="service-showcase-pane" id="showcase-geopolitical-advisory" style="display: none;">
            <div class="showcase-header-row">
              <div class="showcase-icon-badge">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/geopolitical-advisory.png" alt="Geopolitical Advisory">
              </div>
              <div class="showcase-title-area">
                <span class="showcase-category-pill">Strategic Advisory</span>
                <h2 class="showcase-title">Geopolitical Advisory</h2>
              </div>
              <span class="showcase-turnaround-badge">⚡ SLA: Continuous / Scoped</span>
            </div>

            <p class="showcase-desc">Actionable analysis on cross-border political stability, sovereign risk, regulatory shifts, and emerging operational threats.</p>

            <div class="showcase-tags-cloud">
              <span class="showcase-tag-pill">Sovereign Risk</span><span class="showcase-tag-pill">Regulatory Shifts</span><span class="showcase-tag-pill">Supply Chain Security</span><span class="showcase-tag-pill">Executive Travel Security</span>
            </div>

            <h3 class="showcase-section-heading">Core Areas of Verification</h3>
            <div class="showcase-subservices-grid">
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/geopolitical-advisory.png" alt="Country & Sovereign Risk" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Country & Sovereign Risk</h4>
                    <p class="sub-card-desc">Evaluating political stability, expropriation risks, currency controls, and sovereign default indicators.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/civil-record-check.png" alt="Regulatory & Policy Shifts" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Regulatory & Policy Shifts</h4>
                    <p class="sub-card-desc">Forecasting imminent statutory changes, foreign ownership restrictions, and sanction regimes.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/property-record-check.png" alt="Supply Chain Fragility Analysis" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Supply Chain Fragility Analysis</h4>
                    <p class="sub-card-desc">Assessing geopolitical vulnerabilities across maritime chokepoints and border logistics corridors.</p>
                  </div>
                </div>
                <div class="showcase-sub-card">
                  <div class="sub-card-icon-wrap">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/identity-check.png" alt="Executive Travel Security Briefs" style="width:20px; height:20px; object-fit:contain; filter:brightness(0) invert(1);">
                  </div>
                  <div class="sub-card-text">
                    <h4 class="sub-card-title">Executive Travel Security Briefs</h4>
                    <p class="sub-card-desc">Real-time threat assessments, civil unrest alerts, and localized security advisories for travelling teams.</p>
                  </div>
                </div>
            </div>

            <h3 class="showcase-section-heading">Key Verification Deliverables</h3>
            <ul class="showcase-features-list">
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Tailored country risk intelligence bulletins and sovereign vulnerability ratings</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Predictive regulatory forecast matrix highlighting emerging compliance risks</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Executive threat briefing and localized security protocols</span>
                </li>
                <li class="showcase-feature-item">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#083d77" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Direct advisory access to regional subject-matter specialists</span>
                </li>
            </ul>

            <div class="showcase-actions">
              <a href="index.html#quote-form-section" class="btn btn-primary btn-md">
                Request This Verification Check
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"></path><polyline points="12 5 19 12 12 19"></polyline></svg>
              </a>
              <button class="btn btn-secondary btn-md" onclick="openServiceModal('geopolitical-advisory')">
                Quick Summary &amp; Scope
              </button>
              <a href="https://wa.me/13862431035?text=Hello%20Risk%20Verifier%2C%20I%20would%20like%20to%20inquire%20about%20Geopolitical Advisory" target="_blank" class="btn btn-outline btn-md" style="border-color:#083d77; color:#083d77;">
                Direct WhatsApp Inquiry
              </a>
            </div>
          </div>
          </div>
        </div>

      </div>
    </section>

    <!-- 5-Step Verification Process Section -->
    <section class="section section-white" id="how-it-works">
      <div class="container">
        <div class="section-header">
          <h2 class="section-title">How Risk Verification Works</h2>
          <p class="section-subtitle">
            A secure, streamlined 5-step process delivering accurate findings while maintaining strict compliance and confidentiality.
          </p>
        </div>

        <div class="timeline-process-container">
          <!-- Animated Vertical Track -->
          <div class="process-timeline-track">
            <div class="process-timeline-progress"></div>
          </div>

          <div class="process-timeline-items">
            
            <!-- Step 01 -->
            <div class="process-timeline-row step-item-1">
              <div class="timeline-node">
                <div class="timeline-node-inner"></div>
              </div>
              <div class="timeline-connector"></div>

              <div class="process-pill-card">
                <div class="pill-number-wrap">
                  <div class="pill-number-ring">
                    <div class="pill-number-circle">01</div>
                  </div>
                </div>

                <div class="pill-card-content">
                  <h3 class="pill-card-title">Submit Your Request</h3>
                  <p class="pill-card-desc">
                    Tell us what you need to verify and provide the relevant individual, company, document, property, or other subject details. Required authorization or consent is collected securely.
                  </p>
                </div>

                <div class="pill-icon-wrap" title="Request Submission">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                    <line x1="12" y1="18" x2="12" y2="12"></line>
                    <line x1="9" y1="15" x2="15" y2="15"></line>
                  </svg>
                </div>
              </div>
            </div>

            <!-- Step 02 -->
            <div class="process-timeline-row step-item-2">
              <div class="timeline-node">
                <div class="timeline-node-inner"></div>
              </div>
              <div class="timeline-connector"></div>

              <div class="process-pill-card">
                <div class="pill-number-wrap">
                  <div class="pill-number-ring">
                    <div class="pill-number-circle">02</div>
                  </div>
                </div>

                <div class="pill-card-content">
                  <h3 class="pill-card-title">Select Your Verification Services</h3>
                  <p class="pill-card-desc">
                    Choose the checks that match your requirements—from identity, criminal, and civil records to credit, driving records, vital records, due diligence, and bespoke research.
                  </p>
                </div>

                <div class="pill-icon-wrap" title="Service Selection">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="9 11 12 14 22 4"></polyline>
                    <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                  </svg>
                </div>
              </div>
            </div>

            <!-- Step 03 -->
            <div class="process-timeline-row step-item-3">
              <div class="timeline-node">
                <div class="timeline-node-inner"></div>
              </div>
              <div class="timeline-connector"></div>

              <div class="process-pill-card">
                <div class="pill-number-wrap">
                  <div class="pill-number-ring">
                    <div class="pill-number-circle">03</div>
                  </div>
                </div>

                <div class="pill-card-content">
                  <h3 class="pill-card-title">We Research, Verify & Assess</h3>
                  <p class="pill-card-desc">
                    Our team queries authorized official registries, court archives, credit bureaus, and global sanctions databases to undertake tailored research and risk analysis.
                  </p>
                </div>

                <div class="pill-icon-wrap" title="Research & Verification">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    <path d="M11 8v6"></path>
                    <path d="M8 11h6"></path>
                  </svg>
                </div>
              </div>
            </div>

            <!-- Step 04 -->
            <div class="process-timeline-row step-item-4">
              <div class="timeline-node">
                <div class="timeline-node-inner"></div>
              </div>
              <div class="timeline-connector"></div>

              <div class="process-pill-card">
                <div class="pill-number-wrap">
                  <div class="pill-number-ring">
                    <div class="pill-number-circle">04</div>
                  </div>
                </div>

                <div class="pill-card-content">
                  <h3 class="pill-card-title">Receive Your Verified Report</h3>
                  <p class="pill-card-desc">
                    Receive a clear, evidentiary, detailed report presenting verified information and objective risk indicators designed to evaluate credibility and compliance.
                  </p>
                </div>

                <div class="pill-icon-wrap" title="Verified Report">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                    <polyline points="9 12 11 14 15 10"></polyline>
                  </svg>
                </div>
              </div>
            </div>

            <!-- Step 05 -->
            <div class="process-timeline-row step-item-5">
              <div class="timeline-node">
                <div class="timeline-node-inner"></div>
              </div>
              <div class="timeline-connector"></div>

              <div class="process-pill-card">
                <div class="pill-number-wrap">
                  <div class="pill-number-ring">
                    <div class="pill-number-circle">05</div>
                  </div>
                </div>

                <div class="pill-card-content">
                  <h3 class="pill-card-title">Make Confident Decisions</h3>
                  <p class="pill-card-desc">
                    Use verified intelligence to support safer hiring, stronger due diligence, fraud prevention, financial transactions, and proactive risk management.
                  </p>
                </div>

                <div class="pill-icon-wrap" title="Confident Decisions">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                  </svg>
                </div>
              </div>
            </div>

          </div>
        </div>

        <div style="margin-top: 40px; text-align: center;">
          <div style="display: inline-block; padding: 14px 26px; background-color: #ffffff; border: 1.5px solid #083d77; border-radius: 12px; font-size: 0.9rem; color: #083d77; font-weight: 700;">
            ⚡ <strong>Turnaround SLA:</strong> Most background reports are completed within <strong>2 to 7 business days</strong>.
          </div>
        </div>
      </div>
    </section>

    <!-- Why Choose Risk Verifier -->
    <section class="section section-why-dark">
      <!-- Circuit Cyber Glow Watermark at Corners -->
      <div class="circuit-decoration circuit-left" aria-hidden="true">
        <svg width="320" height="180" viewBox="0 0 320 180" fill="none">
          <path d="M0 150 H100 L140 110 H220 L240 90 H300" stroke="#06b6d4" stroke-width="1.5" stroke-opacity="0.3" stroke-dasharray="4 4"/>
          <path d="M0 170 H130 L160 140 H250 L270 120 H320" stroke="#38bdf8" stroke-width="1.5" stroke-opacity="0.25"/>
          <path d="M40 180 L80 140 H130" stroke="#0ea5e9" stroke-width="1" stroke-opacity="0.2"/>
          <circle cx="300" cy="90" r="4" fill="#06b6d4" fill-opacity="0.5"/>
          <circle cx="220" cy="110" r="3" fill="#38bdf8" fill-opacity="0.5"/>
          <circle cx="270" cy="120" r="3" fill="#06b6d4" fill-opacity="0.4"/>
        </svg>
      </div>
      <div class="circuit-decoration circuit-right" aria-hidden="true">
        <svg width="320" height="180" viewBox="0 0 320 180" fill="none">
          <path d="M320 150 H220 L180 110 H100 L80 90 H20" stroke="#06b6d4" stroke-width="1.5" stroke-opacity="0.3" stroke-dasharray="4 4"/>
          <path d="M320 170 H190 L160 140 H70 L50 120 H0" stroke="#38bdf8" stroke-width="1.5" stroke-opacity="0.25"/>
          <path d="M280 180 L240 140 H190" stroke="#0ea5e9" stroke-width="1" stroke-opacity="0.2"/>
          <circle cx="20" cy="90" r="4" fill="#06b6d4" fill-opacity="0.5"/>
          <circle cx="100" cy="110" r="3" fill="#38bdf8" fill-opacity="0.5"/>
          <circle cx="50" cy="120" r="3" fill="#06b6d4" fill-opacity="0.4"/>
        </svg>
      </div>

      <div class="container" style="position: relative; z-index: 2;">
        <div class="section-header">
          <h2 class="section-title">Why Global Organizations Choose Us</h2>
          <p class="section-subtitle">
            Every business relationship and hiring decision carries risk. We make that risk transparent, manageable, and measurable.
          </p>
        </div>

        <div class="why-grid">
          <div class="why-card">
            <div class="why-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
            </div>
            <h4>Reliable Verification</h4>
            <p>We source information directly from government registers, verified police bureaus, and authorized court systems to ensure utmost accuracy.</p>
          </div>

          <div class="why-card">
            <div class="why-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><path d="M9 15l2 2 4-4"></path></svg>
            </div>
            <h4>Comprehensive Screening</h4>
            <p>Bring 12 different risk screening dimensions into a single unified dashboard, eliminating the need to coordinate multiple vendors.</p>
          </div>

          <div class="why-card">
            <div class="why-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
            </div>
            <h4>Practical Insights</h4>
            <p>We don't just dump raw data. We deliver clear, risk-weighted executive summaries that enable immediate executive and HR decisions.</p>
          </div>

          <div class="why-card">
            <div class="why-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
            </div>
            <h4>Strict Confidentiality</h4>
            <p>Subject and client data is protected with bank-grade security and treated with discrete protocols conforming to GDPR and regional privacy laws.</p>
          </div>

          <div class="why-card">
            <div class="why-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
            </div>
            <h4>100+ Countries Coverage</h4>
            <p>Whether you need a criminal check in North America, credential validation in Asia, or due diligence in Europe, we have on-ground capability.</p>
          </div>

          <div class="why-card">
            <div class="why-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>
            </div>
            <h4>Speed & Dedication</h4>
            <p>Fast turnaround times with dedicated account managers and direct WhatsApp lines for urgent, time-sensitive executive vetting.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Interactive Verification Request & Quote Section -->
    <section class="section quote-section" id="quote-form-section">
      <div class="container">
        <div class="quote-wrapper">
          <div class="quote-grid">
            
            <!-- Left: Checkbox Selector & Form -->
            <div class="quote-left">
              <h3>Request a Verification Package</h3>
              <p>Select the checks you need for your candidates or partners and submit your details for an immediate proposal and SLA schedule.</p>
              
              <div id="formResponseAlert" style="display:none;"></div>

              <form id="verificationRequestForm" class="quote-form">
                <label style="font-size:0.875rem; font-weight:800; color:#083d77; margin-bottom: -4px;">Select Required Verification Checks:</label>
                <div class="services-checkbox-grid">
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="criminal-records" checked>
                    <span>Criminal Records</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="civil-records">
                    <span>Civil Records</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="credit-finance" checked>
                    <span>Credit & Finance</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="identity-credentials" checked>
                    <span>ID & Credentials</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="vital-records">
                    <span>Vital Records</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="property-asset">
                    <span>Property & Assets</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="driving-records">
                    <span>Driving / MVR</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="verifications-references">
                    <span>References & HR</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="due-diligence">
                    <span>Due Diligence</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="media-analytics">
                    <span>Media Analytics</span>
                  </label>
                </div>

                <div class="form-row">
                  <div class="form-group">
                    <label for="clientName">Your Full Name / Entity *</label>
                    <input type="text" id="clientName" class="form-input" required placeholder="e.g. Johnathan Smith">
                  </div>
                  <div class="form-group">
                    <label for="clientEmail">Corporate Email Address *</label>
                    <input type="email" id="clientEmail" class="form-input" required placeholder="john@company.com">
                  </div>
                </div>

                <div class="form-row">
                  <div class="form-group">
                    <label for="clientPhone">Phone / WhatsApp *</label>
                    <input type="tel" id="clientPhone" class="form-input" required placeholder="+1 (555) 000-0000">
                  </div>
                  <div class="form-group">
                    <label for="preferredOffice">Assigned Regional Office</label>
                    <select id="preferredOffice" class="form-select">
                      <option value="USA">USA Office (Austin, Texas)</option>
                      <option value="Canada">Canada Office (Ottawa)</option>
                      <option value="UK">UK Office (Reading)</option>
                      <option value="Pakistan">Pakistan Office (Islamabad)</option>
                    </select>
                  </div>
                </div>

                <div class="form-group">
                  <label for="clientNotes">Additional Details / Target Country of Subject</label>
                  <textarea id="clientNotes" class="form-textarea" placeholder="Specify subject location, volume of screenings, or specific requirements..."></textarea>
                </div>

                <button type="submit" class="btn btn-primary btn-lg" style="margin-top: 8px;">
                  Submit Verification Request
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                </button>
              </form>
            </div>

            <!-- Right: Dynamic Order Summary -->
            <div class="quote-right">
              <div class="quote-summary-box">
                <h4>Screening Package Summary</h4>
                
                <ul class="summary-list">
                  <li class="summary-item">
                    <span>Selected Checks:</span>
                    <strong id="selectedCount" style="color:#083d77; font-size:1.1rem;">3</strong>
                  </li>
                  <li class="summary-item">
                    <span>Estimated Turnaround:</span>
                    <strong id="selectedTurnaround">24 – 48 Hours</strong>
                  </li>
                  <li class="summary-item">
                    <span>Coverage Scope:</span>
                    <strong>100+ Countries</strong>
                  </li>
                  <li class="summary-item">
                    <span>Compliance Protocol:</span>
                    <strong>FCRA & GDPR Ready</strong>
                  </li>
                </ul>

                <div style="margin-bottom: 20px;">
                  <span style="font-size:0.8rem; font-weight:700; color:rgba(8,61,119,0.7); text-transform:uppercase; letter-spacing:0.04em; display:block; margin-bottom:8px;">Included in Request:</span>
                  <ul id="selectedServicesList" style="list-style:none; display:flex; flex-direction:column; gap:6px;">
                    <!-- Populated dynamically via JS -->
                  </ul>
                </div>

                <div class="sla-notice">
                  🛡️ <strong>Risk Verifier Guarantee:</strong> All searches are legal, consent-driven, and validated against authoritative registries. No unverified web scraping.
                </div>

                <div style="font-size:0.85rem; color:#083d77; text-align:center;">
                  Need an urgent custom quote? <br>
                  <a href="https://wa.me/13862431035" target="_blank" style="color:#083d77; font-weight:800; display:inline-flex; align-items:center; gap:4px; margin-top:4px; text-decoration:underline;">
                    Chat via WhatsApp (+1 386 243-1035) &rarr;
                  </a>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>

    <!-- Regional Offices Showcase -->
    <section class="section section-white" id="offices">
      <div class="container">
        <div class="section-header">
          <h2 class="section-title">Our Regional Offices</h2>
          <p class="section-subtitle">
            Local knowledge with global capability. Reach out directly to our dedicated regional teams across North America, Europe, and Asia.
          </p>
        </div>

        <div class="offices-grid">
          <!-- USA -->
          <div class="office-card">
            <div class="office-card-top">
              <div class="office-flag">🇺🇸</div>
              <h3 class="office-region">United States</h3>
            </div>
            <p class="office-address">
              5900 Balcones Drive, STE 33098<br>
              Austin, TX 78731<br>
              United States
            </p>
            <div class="office-contacts">
              <a href="tel:+13862431035" class="office-contact-link">
                📞 +1 (386) 243-1035
              </a>
              <a href="mailto:info@riskverifier.com" class="office-contact-link">
                ✉️ info@riskverifier.com
              </a>
              <a href="https://wa.me/13862431035" target="_blank" class="office-whatsapp-btn">
                WhatsApp Austin Desk
              </a>
            </div>
          </div>

          <!-- Canada -->
          <div class="office-card">
            <div class="office-card-top">
              <div class="office-flag">🇨🇦</div>
              <h3 class="office-region">Canada</h3>
            </div>
            <p class="office-address">
              388 Hepatica Way<br>
              Orleans, ON, K4A 0Z1<br>
              Canada
            </p>
            <div class="office-contacts">
              <a href="tel:+14168221904" class="office-contact-link">
                📞 +1 (416) 822-1904
              </a>
              <a href="mailto:info.ca@riskverifier.com" class="office-contact-link">
                ✉️ info.ca@riskverifier.com
              </a>
              <a href="https://wa.me/14168221904" target="_blank" class="office-whatsapp-btn">
                WhatsApp Ottawa Desk
              </a>
            </div>
          </div>

          <!-- United Kingdom -->
          <div class="office-card">
            <div class="office-card-top">
              <div class="office-flag">🇬🇧</div>
              <h3 class="office-region">United Kingdom</h3>
            </div>
            <p class="office-address">
              82 Ashampstead Road<br>
              Reading, Berkshire RG30 3LG<br>
              United Kingdom
            </p>
            <div class="office-contacts">
              <a href="tel:+447973499517" class="office-contact-link">
                📞 +44 7973 499517
              </a>
              <a href="mailto:info.uk@riskverifier.com" class="office-contact-link">
                ✉️ info.uk@riskverifier.com
              </a>
              <a href="https://wa.me/447973499517" target="_blank" class="office-whatsapp-btn">
                WhatsApp UK Desk
              </a>
            </div>
          </div>

          <!-- Pakistan -->
          <div class="office-card">
            <div class="office-card-top">
              <div class="office-flag">🇵🇰</div>
              <h3 class="office-region">Pakistan</h3>
            </div>
            <p class="office-address">
              F-16, First Floor, Galleria Mall<br>
              I-8 Markaz, Islamabad<br>
              Pakistan
            </p>
            <div class="office-contacts">
              <a href="tel:+923005555884" class="office-contact-link">
                📞 +92 300 5555884
              </a>
              <a href="mailto:info@riskverifier.com" class="office-contact-link">
                ✉️ info@riskverifier.com
              </a>
              <a href="https://wa.me/923005555884" target="_blank" class="office-whatsapp-btn">
                WhatsApp Islamabad Desk
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- FAQ Section -->
    <section class="section section-subtle">
      <div class="container" style="max-width: 860px;">
        <div class="section-header">
          <h2 class="section-title">Common Questions & Compliance</h2>
          <p class="section-subtitle">Everything you need to know about our international screening protocols.</p>
        </div>

        <div style="display:flex; flex-direction:column; gap:16px;">
          <details style="background:#ffffff; border:1.5px solid rgba(8,61,119,0.15); border-radius:12px; padding:20px; cursor:pointer;" open>
            <summary style="font-weight:700; color:#083d77; font-size:1.05rem;">How fast is the turnaround time for international checks?</summary>
            <p style="margin-top:12px; color:rgba(8,61,119,0.8); font-size:0.925rem; line-height:1.6;">
              Most standard background checks (Criminal record searches, Credit reports, and Identity verifications) are returned within <strong>24 to 72 hours</strong>. Complex international checks or deep educational registrar verifications typically take 2 to 7 business days depending on the country.
            </p>
          </details>

          <details style="background:#ffffff; border:1.5px solid rgba(8,61,119,0.15); border-radius:12px; padding:20px; cursor:pointer;">
            <summary style="font-weight:700; color:#083d77; font-size:1.05rem;">Are the checks legally compliant and authorized?</summary>
            <p style="margin-top:12px; color:rgba(8,61,119,0.8); font-size:0.925rem; line-height:1.6;">
              Yes. All Risk Verifier checks adhere strictly to local jurisdiction privacy statutes, GDPR in Europe, and FCRA standards in the United States. Where required by law, subject consent forms are collected prior to executing queries.
            </p>
          </details>

          <details style="background:#ffffff; border:1.5px solid rgba(8,61,119,0.15); border-radius:12px; padding:20px; cursor:pointer;">
            <summary style="font-weight:700; color:#083d77; font-size:1.05rem;">Can Risk Verifier handle volume corporate hiring?</summary>
            <p style="margin-top:12px; color:rgba(8,61,119,0.8); font-size:0.925rem; line-height:1.6;">
              Absolutely. We serve multinational corporations, staffing agencies, and government contractors with bulk pre-employment screening packages, automated reporting portals, and tailored corporate SLA agreements.
            </p>
          </details>
        </div>
      </div>
    </section>

  </main>

<?php
get_footer();