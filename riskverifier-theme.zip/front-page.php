<?php
/**
 * The template for displaying the front page
 *
 * @package RiskVerifier
 */

$is_elementor = false;
if (is_singular() || (is_front_page() && get_option('page_on_front'))) {
    $pid = get_the_ID() ?: get_option('page_on_front');
    if ($pid) {
        if (defined('ELEMENTOR_VERSION') && class_exists('\Elementor\Plugin')) {
            $is_elementor = \Elementor\Plugin::$instance->db->is_built_with_elementor($pid);
        }
        if (!$is_elementor && function_exists('get_post_meta')) {
            $is_elementor = (get_post_meta($pid, '_elementor_edit_mode', true) === 'builder');
        }
    }
}

if ($is_elementor) {
    $page_layout = is_singular() ? get_post_meta(get_the_ID(), '_wp_page_template', true) : '';
    if ($page_layout === 'elementor_canvas') {
        while (have_posts()) { the_post(); the_content(); }
        return;
    }
    get_header();
    echo '<main id="main-content" class="elementor-content-container">';
    while (have_posts()) { the_post(); the_content(); }
    echo '</main>';
    get_footer();
    return;
}

get_header();
?>
  <main>
    <!-- Hero Section -->
    <section class="hero" id="hero">
      <!-- Ambient Fluid Topography & Atmospheric Vectors -->
      <div class="hero-ambient-layer" aria-hidden="true">
        <svg class="hero-ambient-wave" viewBox="0 0 1440 680" fill="none" preserveAspectRatio="none">
          <path d="M-60 220 C240 120, 520 340, 840 210 C1120 90, 1360 260, 1540 180" stroke="#0284c7" stroke-opacity="0.06" stroke-width="2" />
          <path d="M-40 310 C260 210, 560 420, 880 300 C1160 180, 1380 350, 1560 270" stroke="#0284c7" stroke-opacity="0.08" stroke-width="1.6" stroke-dasharray="6 8" />
          <path d="M-80 430 C220 320, 500 520, 820 410 C1100 290, 1340 450, 1520 380" stroke="#0284c7" stroke-opacity="0.05" stroke-width="1.8" />
        </svg>
      </div>

      <div class="container">
        <div class="hero-grid">

          <!-- Left Column: Authentic Executive Copy & Titles (from riskverifier.com) -->
          <div class="hero-text-col">
            <h1 class="hero-title">Business Confidence<br>starts with <span class="highlight">Risk Verification</span></h1>

            <p class="hero-description">
              Risk Verifier helps businesses and organizations make confident decisions with accurate and reliable background checks and verifications services.
            </p>

            <div class="hero-actions">
              <a href="#quote-form-section" class="btn btn-primary btn-lg">
                Request a Verification
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
              </a>
              <a href="<?php echo esc_url(home_url('/services/')); ?>" class="btn btn-outline btn-lg">Explore All Services</a>
            </div>

            <!-- Trust Metrics -->
            <div class="hero-metrics">
              <div class="metric-item">
                <span class="metric-value">100+</span>
                <span class="metric-label">Countries Covered</span>
              </div>
              <div class="metric-item">
                <span class="metric-value">24&ndash;72h</span>
                <span class="metric-label">SLA Turnaround</span>
              </div>
              <div class="metric-item">
                <span class="metric-value">12+</span>
                <span class="metric-label">Core Services</span>
              </div>
              <div class="metric-item">
                <span class="metric-value">100%</span>
                <span class="metric-label">Source-Verified</span>
              </div>
            </div>
          </div>

          <!-- Right Column: 3D Rotating World Map Globe & 8 Service Badges -->
          <div class="hero-visual-col">
            <div class="risk-globe-wrapper">
              <!-- Ambient luminous back glow -->
              <div class="globe-ambient-glow"></div>

              <!-- Canvas for 3D Rotating Dotted World Map Globe Sphere & Connection Arcs -->
              <canvas id="heroGlobeCanvas" class="hero-globe-canvas" width="600" height="600"></canvas>

              <!-- SVG 3D Tilted Orbital Rings with Satellite Light Beacons -->
              <svg class="globe-orbits-svg" viewBox="0 0 600 600" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <defs>
                  <linearGradient id="orbitGlow1" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stop-color="#0284c7" stop-opacity="0.75" />
                    <stop offset="50%" stop-color="#38bdf8" stop-opacity="0.35" />
                    <stop offset="100%" stop-color="#083d77" stop-opacity="0.75" />
                  </linearGradient>
                  <filter id="orbitFilter" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="2.5" result="blur" />
                    <feMerge>
                      <feMergeNode in="blur" />
                      <feMergeNode in="SourceGraphic" />
                    </feMerge>
                  </filter>
                </defs>
                <!-- Orbit 1: Tilted -25 deg -->
                <ellipse class="orbit-ellipse orbit-ellipse-1" cx="300" cy="300" rx="235" ry="88" stroke="url(#orbitGlow1)" stroke-width="1.6" filter="url(#orbitFilter)" />
                <!-- Orbit 2: Tilted 20 deg -->
                <ellipse class="orbit-ellipse orbit-ellipse-2" cx="300" cy="300" rx="248" ry="98" stroke="#0284c7" stroke-opacity="0.4" stroke-width="1.4" stroke-dasharray="8 6" />
                <!-- Orbit 3: Tilted 65 deg -->
                <ellipse class="orbit-ellipse orbit-ellipse-3" cx="300" cy="300" rx="225" ry="82" stroke="#083d77" stroke-opacity="0.3" stroke-width="1.3" />
              </svg>

              <!-- 8 Surrounding Orbital Service Badges in Order -->
              <!-- 1. Background Check (Top Center) -->
              <a href="<?php echo esc_url(home_url('/services/#criminal-records')); ?>" class="orbit-badge badge-pos-1" aria-label="Background Check">
                <div class="badge-icon-box icon-bg-check">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    <circle cx="11" cy="9" r="2.5"></circle>
                    <path d="M7 15c0-1.8 1.8-3 4-3s4 1.2 4 3"></path>
                  </svg>
                </div>
                <span class="badge-title">Background Check</span>
              </a>

              <!-- 2. Employment Screening (Top Right) -->
              <a href="<?php echo esc_url(home_url('/services/#verifications-references')); ?>" class="orbit-badge badge-pos-2" aria-label="Employment Screening">
                <div class="badge-icon-box icon-emp-screening">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="10" cy="8" r="4"></circle>
                    <path d="M2 20c0-3.3 2.7-6 6-6h4c3.3 0 6 2.7 6 6"></path>
                    <circle cx="18" cy="11" r="3"></circle>
                    <line x1="20.5" y1="13.5" x2="23" y2="16"></line>
                  </svg>
                </div>
                <span class="badge-title">Employment Screening</span>
              </a>

              <!-- 3. Educational Verification (Middle Right) -->
              <a href="<?php echo esc_url(home_url('/services/#verifications-references')); ?>" class="orbit-badge badge-pos-3" aria-label="Educational Verification">
                <div class="badge-icon-box icon-edu-verification">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M22 10v6M2 10l10-5 10 5-10 5z"></path>
                    <path d="M6 12v5c3 3 9 3 12 0v-5"></path>
                  </svg>
                </div>
                <span class="badge-title">Educational Verification</span>
              </a>

              <!-- 4. Media Analytics (Bottom Right) -->
              <a href="<?php echo esc_url(home_url('/services/#media-analytics')); ?>" class="orbit-badge badge-pos-4" aria-label="Media Analytics">
                <div class="badge-icon-box icon-media-analytics">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline>
                    <polyline points="17 6 23 6 23 12"></polyline>
                  </svg>
                </div>
                <span class="badge-title">Media Analytics</span>
              </a>

              <!-- 5. Due Diligence (Bottom Center) -->
              <a href="<?php echo esc_url(home_url('/services/#due-diligence')); ?>" class="orbit-badge badge-pos-5" aria-label="Due Diligence">
                <div class="badge-icon-box icon-due-diligence">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
                    <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
                    <path d="m9 14 2 2 4-4"></path>
                  </svg>
                </div>
                <span class="badge-title">Due Diligence</span>
              </a>

              <!-- 6. Risk Assessment (Bottom Left) -->
              <a href="<?php echo esc_url(home_url('/services/#civil-records')); ?>" class="orbit-badge badge-pos-6" aria-label="Risk Assessment">
                <div class="badge-icon-box icon-risk-assessment">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path>
                    <line x1="12" y1="9" x2="12" y2="13"></line>
                    <line x1="12" y1="17" x2="12.01" y2="17"></line>
                  </svg>
                </div>
                <span class="badge-title">Risk Assessment</span>
              </a>

              <!-- 7. Bespoke Research (Middle Left) -->
              <a href="<?php echo esc_url(home_url('/services/#bespoke-research')); ?>" class="orbit-badge badge-pos-7" aria-label="Bespoke Research">
                <div class="badge-icon-box icon-bespoke-research">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="22" y1="12" x2="18" y2="12"></line>
                    <line x1="6" y1="12" x2="2" y2="12"></line>
                    <line x1="12" y1="6" x2="12" y2="2"></line>
                    <line x1="12" y1="22" x2="12" y2="18"></line>
                    <circle cx="12" cy="12" r="3"></circle>
                  </svg>
                </div>
                <span class="badge-title">Bespoke Research</span>
              </a>

              <!-- 8. Geo Political Advisory (Top Left) -->
              <a href="<?php echo esc_url(home_url('/services/#geopolitical-advisory')); ?>" class="orbit-badge badge-pos-8" aria-label="Geo Political Advisory">
                <div class="badge-icon-box icon-geo-political">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="2" y1="12" x2="22" y2="12"></line>
                    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                  </svg>
                </div>
                <span class="badge-title">Geo Political Advisory</span>
              </a>
            </div>
          </div>

        </div>
      </div>
    </section>

    <!-- What We Do Section -->
    <section class="section-what-we-do" id="what-we-do">
      <div class="container">
        <div class="wwd-layout">

          <!-- Headline -->
          <div class="wwd-head">
            <span class="wwd-eyebrow">What We Do</span>
            <h2 class="wwd-title">Verify the facts. Decide with confidence.</h2>
            <p class="wwd-lead">Screening, due diligence, research, and advisory services that help organizations spot risk early. Trusted by governments, multinationals, employers, and screening firms.</p>
          </div>

                    <!-- Services -->
          <article class="wwd-item">
            <span class="wwd-icon"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="10" cy="8" r="5"></circle><path d="M2 21a8 8 0 0 1 10.434-7.62"></path><circle cx="18" cy="18" r="3"></circle><path d="m22 22-1.9-1.9"></path></svg></span>
            <h3>Employment Screening</h3>
            <p>Confirm identity, credentials, and work history so every hire is backed by verified facts.</p>
          </article>

          <article class="wwd-item">
            <span class="wwd-icon"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4"></path><path d="M14 13.12c0 2.38 0 6.38-1 8.88"></path><path d="M17.29 21.02c.12-.6.43-2.3.5-3.02"></path><path d="M2 12a10 10 0 0 1 18-6"></path><path d="M2 16h.01"></path><path d="M21.8 16c.2-2 .131-5.354 0-6"></path><path d="M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2"></path><path d="M8.65 22c.21-.66.45-1.32.57-2"></path><path d="M9 6.8a6 6 0 0 1 9 5.2v2"></path></svg></span>
            <h3>Background Check</h3>
            <p>Thorough vetting of criminal, civil, credit, and driving records against official sources.</p>
          </article>

          <article class="wwd-item">
            <span class="wwd-icon"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="M12 8v4"></path><path d="M12 16h.01"></path></svg></span>
            <h3>Risk Management</h3>
            <p>Spot operational and people risks early, with clear assessments you can act on.</p>
          </article>

          <article class="wwd-item">
            <span class="wwd-icon"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h4"></path><path d="M14 2v6h6"></path><path d="M14 2l6 6"></path><circle cx="16" cy="16" r="3"></circle><path d="m21 21-2.4-2.4"></path></svg></span>
            <h3>Due Diligence</h3>
            <p>Deep research on individuals and companies before you partner, invest, or onboard.</p>
          </article>

          <article class="wwd-item">
            <span class="wwd-icon"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2"></path><path d="M18 14h-8"></path><path d="M15 18h-5"></path><path d="M10 6h8v4h-8V6Z"></path></svg></span>
            <h3>Media Analytics</h3>
            <p>Monitor public records, news, and online signals that shape reputation.</p>
          </article>

          <article class="wwd-item">
            <span class="wwd-icon"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"></path><path d="M2 12h20"></path></svg></span>
            <h3>Geopolitical Advisories</h3>
            <p>Understand emerging risks, market shifts, and complex operating environments.</p>
          </article>

        </div>
      </div>
    </section>

    <!-- Services Section (Favif Digital Layout with Brand Blue & Pure White) -->
    <section class="favif-services-section" id="services-catalog">
      <div class="container favif-services-container">
        
        <!-- Sticky Left Column -->
        <div class="favif-services-left">
          <div class="favif-eyebrow">
            <span class="favif-eyebrow-dot" aria-hidden="true"></span>
            <span class="favif-eyebrow-text">Our Services</span>
          </div>

          <h2 class="favif-services-title">
            Everything your business needs to verify.
            <span class="title-accent">One trusted partner. 100+ countries.</span>
          </h2>

          <p class="favif-services-desc">
            From criminal registries and court dockets to corporate due diligence and asset tracing — we deliver direct-source evidentiary certainty across 100+ jurisdictions.
          </p>

          <!-- Category Filter Pills -->
          <div class="favif-filter-nav">
            <button class="favif-filter-btn active" data-filter="all">
              <span>All 12 Services</span>
              <span class="favif-filter-count">12</span>
            </button>
            <button class="favif-filter-btn" data-filter="legal">
              <span>Criminal & Legal</span>
              <span class="favif-filter-count">2</span>
            </button>
            <button class="favif-filter-btn" data-filter="financial">
              <span>Financial & Property</span>
              <span class="favif-filter-count">2</span>
            </button>
            <button class="favif-filter-btn" data-filter="identity">
              <span>Identity & Credentials</span>
              <span class="favif-filter-count">4</span>
            </button>
            <button class="favif-filter-btn" data-filter="advisory">
              <span>Due Diligence & Advisory</span>
              <span class="favif-filter-count">4</span>
            </button>
          </div>

          <a href="services.html" class="favif-services-cta">
            <span>Explore All Capabilities</span>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M5 12h14"></path>
              <polyline points="12 5 19 12 12 19"></polyline>
            </svg>
          </a>
        </div>

        <!-- Right Bento Grid -->
        <div class="favif-bento-grid" id="servicesBentoGrid">
          
          <!-- Card 01: Criminal Records Check -->
          <div class="favif-bento-card" data-category="legal" onclick="openServiceModal('criminal-records')">
            <div class="favif-card-header">
              <span class="favif-card-badge">Legal Screening</span>
              <span class="favif-card-sla">24–72h</span>
            </div>
            <div class="favif-card-icon-wrap">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/criminal-record-check.png" alt="Criminal Records Check" loading="lazy">
            </div>
            <h3 class="favif-card-title">Criminal Records Check</h3>
            <p class="favif-card-desc">Comprehensive criminal background checks across law enforcement and court archives to ensure safe hiring and regulatory compliance.</p>
            <div class="favif-card-footer">
              <span class="favif-card-action">
                View Verification Details
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
              </span>
            </div>
          </div>

          <!-- Card 02: Civil Records Search -->
          <div class="favif-bento-card" data-category="legal" onclick="openServiceModal('civil-records')">
            <div class="favif-card-header">
              <span class="favif-card-badge">Legal Screening</span>
              <span class="favif-card-sla">24–48h</span>
            </div>
            <div class="favif-card-icon-wrap">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/civil-record-check.png" alt="Civil Records Search" loading="lazy">
            </div>
            <h3 class="favif-card-title">Civil Records Search</h3>
            <p class="favif-card-desc">Access court filings, commercial dispute records, bankruptcies, and litigation history to uncover hidden contractual liabilities.</p>
            <div class="favif-card-footer">
              <span class="favif-card-action">
                View Verification Details
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
              </span>
            </div>
          </div>

          <!-- Card 03: Credit & Finance Reports -->
          <div class="favif-bento-card" data-category="financial" onclick="openServiceModal('credit-finance')">
            <div class="favif-card-header">
              <span class="favif-card-badge">Financial Risk</span>
              <span class="favif-card-sla">24–48h</span>
            </div>
            <div class="favif-card-icon-wrap">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/credit-record-check.png" alt="Credit & Finance Reports" loading="lazy">
            </div>
            <h3 class="favif-card-title">Credit & Finance Reports</h3>
            <p class="favif-card-desc">Official credit bureau history, debt obligations, solvency ratings, and tax lien analysis for individual and corporate entities.</p>
            <div class="favif-card-footer">
              <span class="favif-card-action">
                View Verification Details
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
              </span>
            </div>
          </div>

          <!-- Card 04: Vital Records Verification -->
          <div class="favif-bento-card" data-category="identity" onclick="openServiceModal('vital-records')">
            <div class="favif-card-header">
              <span class="favif-card-badge">Identity Records</span>
              <span class="favif-card-sla">2–5 Days</span>
            </div>
            <div class="favif-card-icon-wrap">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/vital-record-check.png" alt="Vital Records Verification" loading="lazy">
            </div>
            <h3 class="favif-card-title">Vital Records Verification</h3>
            <p class="favif-card-desc">Authentication of birth certificates, marital status records, death registries, and apostilles across civil registry archives.</p>
            <div class="favif-card-footer">
              <span class="favif-card-action">
                View Verification Details
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
              </span>
            </div>
          </div>

          <!-- Card 05: Identity & Credentials -->
          <div class="favif-bento-card" data-category="identity" onclick="openServiceModal('identity-credentials')">
            <div class="favif-card-header">
              <span class="favif-card-badge">Identity & Credentials</span>
              <span class="favif-card-sla">24–48h</span>
            </div>
            <div class="favif-card-icon-wrap">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/identity-check.png" alt="Identity & Credentials Verification" loading="lazy">
            </div>
            <h3 class="favif-card-title">Identity & Credentials</h3>
            <p class="favif-card-desc">Validation of government IDs, passports, academic degrees directly from registrars, and professional license registries.</p>
            <div class="favif-card-footer">
              <span class="favif-card-action">
                View Verification Details
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
              </span>
            </div>
          </div>

          <!-- Card 06: Property & Asset Searches -->
          <div class="favif-bento-card" data-category="financial" onclick="openServiceModal('property-asset')">
            <div class="favif-card-header">
              <span class="favif-card-badge">Asset Intelligence</span>
              <span class="favif-card-sla">2–4 Days</span>
            </div>
            <div class="favif-card-icon-wrap">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/property-record-check.png" alt="Property & Asset Searches" loading="lazy">
            </div>
            <h3 class="favif-card-title">Property & Asset Searches</h3>
            <p class="favif-card-desc">Investigation of real estate deeds, corporate asset registers, mortgages, and encumbrances to evaluate net worth and collateral.</p>
            <div class="favif-card-footer">
              <span class="favif-card-action">
                View Verification Details
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
              </span>
            </div>
          </div>

          <!-- Card 07: Driving & Motor Vehicle Records -->
          <div class="favif-bento-card" data-category="identity" onclick="openServiceModal('driving-records')">
            <div class="favif-card-header">
              <span class="favif-card-badge">Motor Vehicle Records</span>
              <span class="favif-card-sla">24–48h</span>
            </div>
            <div class="favif-card-icon-wrap">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/driving-record-check.png" alt="Driving & Motor Vehicle Records" loading="lazy">
            </div>
            <h3 class="favif-card-title">Driving & MVR Records</h3>
            <p class="favif-card-desc">Direct DMV driver histories, license validity status, traffic infractions, suspension orders, and CDL endorsements for fleet safety.</p>
            <div class="favif-card-footer">
              <span class="favif-card-action">
                View Verification Details
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
              </span>
            </div>
          </div>

          <!-- Card 08: Verifications & References -->
          <div class="favif-bento-card" data-category="identity" onclick="openServiceModal('verifications-references')">
            <div class="favif-card-header">
              <span class="favif-card-badge">HR & Employment</span>
              <span class="favif-card-sla">2–4 Days</span>
            </div>
            <div class="favif-card-icon-wrap">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/reference-check.png" alt="Verifications & References" loading="lazy">
            </div>
            <h3 class="favif-card-title">Verifications & References</h3>
            <p class="favif-card-desc">Direct HR employment tenure verification, job title authentication, rehire eligibility, and structured supervisor reference interviews.</p>
            <div class="favif-card-footer">
              <span class="favif-card-action">
                View Verification Details
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
              </span>
            </div>
          </div>

          <!-- Card 09: Due Diligence & Sanctions Screening -->
          <div class="favif-bento-card" data-category="advisory" onclick="openServiceModal('due-diligence')">
            <div class="favif-card-header">
              <span class="favif-card-badge">Due Diligence</span>
              <span class="favif-card-sla">3–5 Days</span>
            </div>
            <div class="favif-card-icon-wrap">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/due-diligence.png" alt="Due Diligence & Sanctions Screening" loading="lazy">
            </div>
            <h3 class="favif-card-title">Due Diligence & Sanctions</h3>
            <p class="favif-card-desc">Cross-referencing entities against international sanctions lists, PEP databases, adverse media, and ultimate beneficial ownership (UBO).</p>
            <div class="favif-card-footer">
              <span class="favif-card-action">
                View Verification Details
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
              </span>
            </div>
          </div>

          <!-- Card 10: Media Analytics -->
          <div class="favif-bento-card" data-category="advisory" onclick="openServiceModal('media-analytics')">
            <div class="favif-card-header">
              <span class="favif-card-badge">Risk Intelligence</span>
              <span class="favif-card-sla">2–4 Days</span>
            </div>
            <div class="favif-card-icon-wrap">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/media-analytics.png" alt="Media Analytics" loading="lazy">
            </div>
            <h3 class="favif-card-title">Media Analytics</h3>
            <p class="favif-card-desc">Automated analysis of news sentiment, regulatory notices, and digital media footprints to identify emerging reputational risks.</p>
            <div class="favif-card-footer">
              <span class="favif-card-action">
                View Verification Details
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
              </span>
            </div>
          </div>

          <!-- Card 11: Bespoke Research -->
          <div class="favif-bento-card" data-category="advisory" onclick="openServiceModal('bespoke-research')">
            <div class="favif-card-header">
              <span class="favif-card-badge">Custom Intelligence</span>
              <span class="favif-card-sla">Tailored</span>
            </div>
            <div class="favif-card-icon-wrap">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/bespoke-research.png" alt="Bespoke Research" loading="lazy">
            </div>
            <h3 class="favif-card-title">Bespoke Research</h3>
            <p class="favif-card-desc">Custom-tailored investigative intelligence for complex cross-border M&A transactions, executive vetting, and counterparty profiling.</p>
            <div class="favif-card-footer">
              <span class="favif-card-action">
                View Verification Details
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
              </span>
            </div>
          </div>

          <!-- Card 12: Geopolitical Advisory -->
          <div class="favif-bento-card" data-category="advisory" onclick="openServiceModal('geopolitical-advisory')">
            <div class="favif-card-header">
              <span class="favif-card-badge">Strategic Advisory</span>
              <span class="favif-card-sla">Continuous</span>
            </div>
            <div class="favif-card-icon-wrap">
              <img src="<?php echo get_template_directory_uri(); ?>/assets/icon/geopolitical-advisory.png" alt="Geopolitical Advisory" loading="lazy">
            </div>
            <h3 class="favif-card-title">Geopolitical Advisory</h3>
            <p class="favif-card-desc">Sovereign risk assessment, regulatory change intelligence, supply chain stability analysis, and executive travel security briefs.</p>
            <div class="favif-card-footer">
              <span class="favif-card-action">
                View Verification Details
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
              </span>
            </div>
          </div>

        </div>

      </div>
    </section>

    <!-- 5-Step Verification Process Section (Alternating Portal Timeline) -->
    <section class="section section-white" id="how-it-works">
      <div class="container">
        <!-- Section Header -->
        <div class="svc-header-container">
          <h2 class="svc-main-title">
            <span class="svc-title-light">HOW RISK</span> VERIFICATION WORKS
          </h2>
          <div class="svc-title-underline"></div>
          <p class="svc-header-desc">
            A secure, streamlined 5-step methodology delivering direct-source findings while maintaining strict regulatory compliance and confidentiality.
          </p>
        </div>

        <!-- Central Alternating Timeline for 5 Steps -->
        <div class="svc-timeline-container hiw-portal-timeline">
          <div class="svc-timeline-track"></div>

          <!-- Step 01: Submit Your Request (Odd: Content Left, Center Node, Ghost Num Right) -->
          <div class="svc-timeline-row row-odd svc-side-left">
            <div class="svc-timeline-content">
              <span class="svc-turnaround-badge">Step 01 • Intake</span>
              <h3 class="svc-content-title">SUBMIT YOUR REQUEST</h3>
              <p class="svc-content-desc">
                Submit subject details (individual, corporate entity, property, or document). Required authorization and candidate consent are securely collected through encrypted digital workflows.
              </p>
              <div class="showcase-tags-cloud" style="margin-bottom:0; margin-top:12px;">
                <span class="showcase-tag-pill">Encrypted Data Intake</span>
                <span class="showcase-tag-pill">Consent Authorization</span>
              </div>
            </div>

            <div class="svc-timeline-center">
              <div class="svc-connector-line"></div>
              <div class="svc-portal-node">
                <div class="svc-portal-glow"></div>
                <div class="svc-portal-outer-ring"></div>
                <div class="svc-portal-mid-ring"></div>
                <div class="svc-portal-circle">
                  <svg class="svc-portal-icon" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                    <line x1="12" y1="18" x2="12" y2="12"></line>
                    <polyline points="9 15 12 12 15 15"></polyline>
                  </svg>
                </div>
              </div>
            </div>

            <div class="svc-timeline-number">
              <span class="svc-ghost-num">01</span>
            </div>
          </div>

          <!-- Step 02: Verification Scope & Selection (Even: Ghost Num Left, Center Node, Content Right) -->
          <div class="svc-timeline-row row-even svc-side-right">
            <div class="svc-timeline-number">
              <span class="svc-ghost-num">02</span>
            </div>

            <div class="svc-timeline-center">
              <div class="svc-connector-line"></div>
              <div class="svc-portal-node">
                <div class="svc-portal-glow"></div>
                <div class="svc-portal-outer-ring"></div>
                <div class="svc-portal-mid-ring"></div>
                <div class="svc-portal-circle">
                  <svg class="svc-portal-icon" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M9 6h11"></path>
                    <path d="M9 12h11"></path>
                    <path d="M9 18h11"></path>
                    <polyline points="4 6 5.5 7.5 8 5"></polyline>
                    <polyline points="4 12 5.5 13.5 8 11"></polyline>
                    <polyline points="4 18 5.5 19.5 8 17"></polyline>
                  </svg>
                </div>
              </div>
            </div>

            <div class="svc-timeline-content">
              <span class="svc-turnaround-badge">Step 02 • Scope</span>
              <h3 class="svc-content-title">SELECT VERIFICATION SERVICES</h3>
              <p class="svc-content-desc">
                Configure screening dimensions aligned with your compliance risk profile—spanning criminal, civil litigation, credit solvency, vital records, credentials, or deep corporate due diligence.
              </p>
              <div class="showcase-tags-cloud" style="margin-bottom:0; margin-top:12px;">
                <span class="showcase-tag-pill">12 Specialized Vectors</span>
                <span class="showcase-tag-pill">Custom Risk Profiling</span>
              </div>
            </div>
          </div>

          <!-- Step 03: Direct Investigation & Cross-Referencing (Odd) -->
          <div class="svc-timeline-row row-odd svc-side-left">
            <div class="svc-timeline-content">
              <span class="svc-turnaround-badge">Step 03 • Investigation</span>
              <h3 class="svc-content-title">RESEARCH, VERIFY & CROSS-REFERENCE</h3>
              <p class="svc-content-desc">
                Our vetted analysts query authorized government registers, law enforcement repositories, court dockets, credit bureaus, and global sanctions lists to extract factual, untampered intelligence.
              </p>
              <div class="showcase-tags-cloud" style="margin-bottom:0; margin-top:12px;">
                <span class="showcase-tag-pill">Direct Source Archives</span>
                <span class="showcase-tag-pill">Global Sanctions & PEP</span>
              </div>
            </div>

            <div class="svc-timeline-center">
              <div class="svc-connector-line"></div>
              <div class="svc-portal-node">
                <div class="svc-portal-glow"></div>
                <div class="svc-portal-outer-ring"></div>
                <div class="svc-portal-mid-ring"></div>
                <div class="svc-portal-circle">
                  <svg class="svc-portal-icon" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    <polyline points="8 11 10.5 13.5 14.5 9.5"></polyline>
                  </svg>
                </div>
              </div>
            </div>

            <div class="svc-timeline-number">
              <span class="svc-ghost-num">03</span>
            </div>
          </div>

          <!-- Step 04: Consolidated Intelligence Report (Even) -->
          <div class="svc-timeline-row row-even svc-side-right">
            <div class="svc-timeline-number">
              <span class="svc-ghost-num">04</span>
            </div>

            <div class="svc-timeline-center">
              <div class="svc-connector-line"></div>
              <div class="svc-portal-node">
                <div class="svc-portal-glow"></div>
                <div class="svc-portal-outer-ring"></div>
                <div class="svc-portal-mid-ring"></div>
                <div class="svc-portal-circle">
                  <svg class="svc-portal-icon" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
                    <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
                    <path d="M9 14l2 2 4-4"></path>
                  </svg>
                </div>
              </div>
            </div>

            <div class="svc-timeline-content">
              <span class="svc-turnaround-badge">Step 04 • Reporting</span>
              <h3 class="svc-content-title">RECEIVE CONSOLIDATED REPORT</h3>
              <p class="svc-content-desc">
                Receive an executive, evidentiary dossier featuring verified records, official timestamps, clarity indexes, and risk categorization—enabling swift assessment without data ambiguity.
              </p>
              <div class="showcase-tags-cloud" style="margin-bottom:0; margin-top:12px;">
                <span class="showcase-tag-pill">Evidentiary Documentation</span>
                <span class="showcase-tag-pill">Executive Risk Index</span>
              </div>
            </div>
          </div>

          <!-- Step 05: Confident Decision Making (Odd) -->
          <div class="svc-timeline-row row-odd svc-side-left">
            <div class="svc-timeline-content">
              <span class="svc-turnaround-badge">Step 05 • Decision</span>
              <h3 class="svc-content-title">MAKE CONFIDENT DECISIONS</h3>
              <p class="svc-content-desc">
                Leverage tamper-proof intelligence to support safe executive hiring, robust vendor onboarding, commercial transaction due diligence, and regulatory compliance protection.
              </p>
              <div class="showcase-tags-cloud" style="margin-bottom:0; margin-top:12px;">
                <span class="showcase-tag-pill">Protected Governance</span>
                <span class="showcase-tag-pill">Total Risk Mitigation</span>
              </div>
            </div>

            <div class="svc-timeline-center">
              <div class="svc-connector-line"></div>
              <div class="svc-portal-node">
                <div class="svc-portal-glow"></div>
                <div class="svc-portal-outer-ring"></div>
                <div class="svc-portal-mid-ring"></div>
                <div class="svc-portal-circle">
                  <svg class="svc-portal-icon" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                    <polyline points="9 12 11 14 15 10"></polyline>
                  </svg>
                </div>
              </div>
            </div>

            <div class="svc-timeline-number">
              <span class="svc-ghost-num">05</span>
            </div>
          </div>

        </div>

        <div style="margin-top: 40px; text-align: center;">
          <div style="display: inline-block; padding: 14px 26px; background-color: #ffffff; border: 1.5px solid #083d77; border-radius: 12px; font-size: 0.9rem; color: #083d77; font-weight: 700; box-shadow: 0 4px 14px rgba(8,61,119,0.06);">
            ⚡ <strong>Turnaround SLA:</strong> Standard background verification delivered in <strong>24 to 72 hours</strong>. Complex global due diligence in 2 to 7 business days.
          </div>
        </div>
      </div>
    </section>

    <!-- Why Choose Risk Verifier -->
    <section class="section section-why-dark">
      <!-- Circuit Cyber Glow Watermark at Corners -->
      <div class="circuit-decoration circuit-left" aria-hidden="true">
        <svg width="320" height="180" viewBox="0 0 320 180" fill="none">
          <path d="M0 150 H100 L140 110 H220 L240 90 H300" stroke="#06b6d4" stroke-width="1.5" stroke-opacity="0.3" stroke-dasharray="4 4"/>
          <path d="M0 170 H130 L160 140 H250 L270 120 H320" stroke="#38bdf8" stroke-width="1.5" stroke-opacity="0.25"/>
          <path d="M40 180 L80 140 H130" stroke="#0ea5e9" stroke-width="1" stroke-opacity="0.2"/>
          <circle cx="300" cy="90" r="4" fill="#06b6d4" fill-opacity="0.5"/>
          <circle cx="220" cy="110" r="3" fill="#38bdf8" fill-opacity="0.5"/>
          <circle cx="270" cy="120" r="3" fill="#06b6d4" fill-opacity="0.4"/>
        </svg>
      </div>
      <div class="circuit-decoration circuit-right" aria-hidden="true">
        <svg width="320" height="180" viewBox="0 0 320 180" fill="none">
          <path d="M320 150 H220 L180 110 H100 L80 90 H20" stroke="#06b6d4" stroke-width="1.5" stroke-opacity="0.3" stroke-dasharray="4 4"/>
          <path d="M320 170 H190 L160 140 H70 L50 120 H0" stroke="#38bdf8" stroke-width="1.5" stroke-opacity="0.25"/>
          <path d="M280 180 L240 140 H190" stroke="#0ea5e9" stroke-width="1" stroke-opacity="0.2"/>
          <circle cx="20" cy="90" r="4" fill="#06b6d4" fill-opacity="0.5"/>
          <circle cx="100" cy="110" r="3" fill="#38bdf8" fill-opacity="0.5"/>
          <circle cx="50" cy="120" r="3" fill="#06b6d4" fill-opacity="0.4"/>
        </svg>
      </div>

      <div class="container" style="position: relative; z-index: 2;">
        <div class="section-header">
          <h2 class="section-title">Why Global Organizations Choose Us</h2>
          <p class="section-subtitle">
            Every business relationship and hiring decision carries risk. We make that risk transparent, manageable, and measurable.
          </p>
        </div>

        <div class="why-grid">
          <div class="why-card">
            <div class="why-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
            </div>
            <h4>Reliable Verification</h4>
            <p>We source information directly from government registers, verified police bureaus, and authorized court systems to ensure utmost accuracy.</p>
          </div>

          <div class="why-card">
            <div class="why-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><path d="M9 15l2 2 4-4"></path></svg>
            </div>
            <h4>Comprehensive Screening</h4>
            <p>Bring 12 different risk screening dimensions into a single unified dashboard, eliminating the need to coordinate multiple vendors.</p>
          </div>

          <div class="why-card">
            <div class="why-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
            </div>
            <h4>Practical Insights</h4>
            <p>We don't just dump raw data. We deliver clear, risk-weighted executive summaries that enable immediate executive and HR decisions.</p>
          </div>

          <div class="why-card">
            <div class="why-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
            </div>
            <h4>Strict Confidentiality</h4>
            <p>Subject and client data is protected with bank-grade security and treated with discrete protocols conforming to GDPR and regional privacy laws.</p>
          </div>

          <div class="why-card">
            <div class="why-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
            </div>
            <h4>100+ Countries Coverage</h4>
            <p>Whether you need a criminal check in North America, credential validation in Asia, or due diligence in Europe, we have on-ground capability.</p>
          </div>

          <div class="why-card">
            <div class="why-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>
            </div>
            <h4>Speed & Dedication</h4>
            <p>Fast turnaround times with dedicated account managers and direct WhatsApp lines for urgent, time-sensitive executive vetting.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Interactive Verification Request & Quote Section -->
    <section class="section quote-section" id="quote-form-section">
      <div class="container">
        <div class="quote-wrapper">
          <div class="quote-grid">
            
            <!-- Left: Checkbox Selector & Form -->
            <div class="quote-left">
              <h3>Request a Verification Package</h3>
              <p>Select the checks you need for your candidates or partners and submit your details for an immediate proposal and SLA schedule.</p>
              
              <div id="formResponseAlert" style="display:none;"></div>

              <form id="verificationRequestForm" class="quote-form">
                <label style="font-size:0.875rem; font-weight:800; color:#083d77; margin-bottom: -4px;">Select Required Verification Checks:</label>
                <div class="services-checkbox-grid">
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="criminal-records" checked>
                    <span>Criminal Records</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="civil-records">
                    <span>Civil Records</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="credit-finance" checked>
                    <span>Credit & Finance</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="identity-credentials" checked>
                    <span>ID & Credentials</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="vital-records">
                    <span>Vital Records</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="property-asset">
                    <span>Property & Assets</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="driving-records">
                    <span>Driving / MVR</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="verifications-references">
                    <span>References & HR</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="due-diligence">
                    <span>Due Diligence</span>
                  </label>
                  <label class="checkbox-pill">
                    <input type="checkbox" name="services" value="media-analytics">
                    <span>Media Analytics</span>
                  </label>
                </div>

                <div class="form-row">
                  <div class="form-group">
                    <label for="clientName">Your Full Name / Entity *</label>
                    <input type="text" id="clientName" class="form-input" required placeholder="e.g. Johnathan Smith">
                  </div>
                  <div class="form-group">
                    <label for="clientEmail">Corporate Email Address *</label>
                    <input type="email" id="clientEmail" class="form-input" required placeholder="john@company.com">
                  </div>
                </div>

                <div class="form-row">
                  <div class="form-group">
                    <label for="clientPhone">Phone / WhatsApp *</label>
                    <input type="tel" id="clientPhone" class="form-input" required placeholder="+1 (555) 000-0000">
                  </div>
                  <div class="form-group">
                    <label for="preferredOffice">Assigned Regional Office</label>
                    <select id="preferredOffice" class="form-select">
                      <option value="USA">USA Office (Austin, Texas)</option>
                      <option value="Canada">Canada Office (Ottawa)</option>
                      <option value="UK">UK Office (Reading)</option>
                      <option value="Pakistan">Pakistan Office (Islamabad)</option>
                    </select>
                  </div>
                </div>

                <div class="form-group">
                  <label for="clientNotes">Additional Details / Target Country of Subject</label>
                  <textarea id="clientNotes" class="form-textarea" placeholder="Specify subject location, volume of screenings, or specific requirements..."></textarea>
                </div>

                <button type="submit" class="btn btn-primary btn-lg" style="margin-top: 8px;">
                  Submit Verification Request
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                </button>
              </form>
            </div>

            <!-- Right: Dynamic Order Summary -->
            <div class="quote-right">
              <div class="quote-summary-box">
                <h4>Screening Package Summary</h4>
                
                <ul class="summary-list">
                  <li class="summary-item">
                    <span>Selected Checks:</span>
                    <strong id="selectedCount" style="color:#083d77; font-size:1.1rem;">3</strong>
                  </li>
                  <li class="summary-item">
                    <span>Estimated Turnaround:</span>
                    <strong id="selectedTurnaround">24 – 48 Hours</strong>
                  </li>
                  <li class="summary-item">
                    <span>Coverage Scope:</span>
                    <strong>100+ Countries</strong>
                  </li>
                  <li class="summary-item">
                    <span>Compliance Protocol:</span>
                    <strong>FCRA & GDPR Ready</strong>
                  </li>
                </ul>

                <div style="margin-bottom: 20px;">
                  <span style="font-size:0.8rem; font-weight:700; color:rgba(8,61,119,0.7); text-transform:uppercase; letter-spacing:0.04em; display:block; margin-bottom:8px;">Included in Request:</span>
                  <ul id="selectedServicesList" style="list-style:none; display:flex; flex-direction:column; gap:6px;">
                    <!-- Populated dynamically via JS -->
                  </ul>
                </div>

                <div class="sla-notice">
                  🛡️ <strong>Risk Verifier Guarantee:</strong> All searches are legal, consent-driven, and validated against authoritative registries. No unverified web scraping.
                </div>

                <div style="font-size:0.85rem; color:#083d77; text-align:center;">
                  Need an urgent custom quote? <br>
                  <a href="https://wa.me/13862431035" target="_blank" style="color:#083d77; font-weight:800; display:inline-flex; align-items:center; gap:4px; margin-top:4px; text-decoration:underline;">
                    Chat via WhatsApp (+1 386 243-1035) &rarr;
                  </a>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>

    <!-- Regional Offices Showcase -->
    <section class="section section-white" id="offices">
      <div class="container">
        <div class="section-header">
          <h2 class="section-title">Our Regional Offices</h2>
          <p class="section-subtitle">
            Local knowledge with global capability. Reach out directly to our dedicated regional teams across North America, Europe, and Asia.
          </p>
        </div>

        <div class="offices-grid">
          <!-- USA -->
          <div class="office-card">
            <div class="office-card-top">
              <div class="office-flag"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/flags/us.svg'); ?>" alt="United States" class="office-flag-img"></div>
              <h3 class="office-region">United States</h3>
            </div>
            <p class="office-address">
              Austin, United States
            </p>
            <div class="office-contacts">
              <a href="tel:+13862431035" class="office-contact-link">
                📞 +1 (386) 243-1035
              </a>
              <a href="mailto:info@riskverifier.com" class="office-contact-link">
                ✉️ info@riskverifier.com
              </a>
              <a href="https://wa.me/13862431035" target="_blank" class="office-whatsapp-btn">
                WhatsApp Austin Desk
              </a>
            </div>
          </div>

          <!-- Canada -->
          <div class="office-card">
            <div class="office-card-top">
              <div class="office-flag"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/flags/ca.svg'); ?>" alt="Canada" class="office-flag-img"></div>
              <h3 class="office-region">Canada</h3>
            </div>
            <p class="office-address">
              Ottawa, Canada
            </p>
            <div class="office-contacts">
              <a href="tel:+14168221904" class="office-contact-link">
                📞 +1 (416) 822-1904
              </a>
              <a href="mailto:info.ca@riskverifier.com" class="office-contact-link">
                ✉️ info.ca@riskverifier.com
              </a>
              <a href="https://wa.me/14168221904" target="_blank" class="office-whatsapp-btn">
                WhatsApp Ottawa Desk
              </a>
            </div>
          </div>

          <!-- United Kingdom -->
          <div class="office-card">
            <div class="office-card-top">
              <div class="office-flag"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/flags/gb.svg'); ?>" alt="United Kingdom" class="office-flag-img"></div>
              <h3 class="office-region">United Kingdom</h3>
            </div>
            <p class="office-address">
              Reading, United Kingdom
            </p>
            <div class="office-contacts">
              <a href="tel:+447973499517" class="office-contact-link">
                📞 +44 7973 499517
              </a>
              <a href="mailto:info.uk@riskverifier.com" class="office-contact-link">
                ✉️ info.uk@riskverifier.com
              </a>
              <a href="https://wa.me/447973499517" target="_blank" class="office-whatsapp-btn">
                WhatsApp UK Desk
              </a>
            </div>
          </div>

          <!-- Pakistan -->
          <div class="office-card">
            <div class="office-card-top">
              <div class="office-flag"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/flags/pk.svg'); ?>" alt="Pakistan" class="office-flag-img"></div>
              <h3 class="office-region">Pakistan</h3>
            </div>
            <p class="office-address">
              Islamabad, Pakistan
            </p>
            <div class="office-contacts">
              <a href="tel:+923005555884" class="office-contact-link">
                📞 +92 300 5555884
              </a>
              <a href="mailto:info@riskverifier.com" class="office-contact-link">
                ✉️ info@riskverifier.com
              </a>
              <a href="https://wa.me/923005555884" target="_blank" class="office-whatsapp-btn">
                WhatsApp Islamabad Desk
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Common Questions & Compliance Section (Capsule Timeline Design) -->
    <section class="faq-timeline-section" id="faq">
      <div class="container" style="max-width: 900px;">
        <div class="svc-header-container" style="margin-bottom: 40px;">
          <h2 class="svc-main-title">
            <span class="svc-title-light">COMMON QUESTIONS &amp;</span> COMPLIANCE
          </h2>
          <div class="svc-title-underline"></div>
          <p class="svc-header-desc">
            Everything corporate legal counsel, HR leaders, and compliance officers need to know about our global verification protocols.
          </p>
        </div>

        <div class="faq-timeline-container">
          <div class="faq-timeline-track">
            <div class="faq-timeline-progress"></div>
          </div>

          <div class="faq-timeline-items">
            
            <!-- FAQ 01 -->
            <div class="faq-timeline-row">
              <div class="faq-timeline-node">
                <div class="faq-timeline-node-inner"></div>
              </div>
              <div class="faq-timeline-connector"></div>

              <div class="faq-capsule-card active">
                <div class="faq-capsule-num">01</div>
                <div class="faq-capsule-body">
                  <h3 class="faq-capsule-question">How fast is the turnaround time for international background checks?</h3>
                  <div class="faq-capsule-answer">
                    Most standard individual verification packages (Criminal record searches, Credit reports, and Identity credentials) are completed and delivered within <strong>24 to 72 hours</strong>. Complex cross-border checks, university registrar archives, or deep in-person court record searches generally require <strong>2 to 7 business days</strong> depending on local jurisdictional procedures.
                  </div>
                </div>
                <div class="faq-capsule-toggle" aria-label="Toggle answer">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="6 9 12 15 18 9"></polyline>
                  </svg>
                </div>
              </div>
            </div>

            <!-- FAQ 02 -->
            <div class="faq-timeline-row">
              <div class="faq-timeline-node">
                <div class="faq-timeline-node-inner"></div>
              </div>
              <div class="faq-timeline-connector"></div>

              <div class="faq-capsule-card">
                <div class="faq-capsule-num">02</div>
                <div class="faq-capsule-body">
                  <h3 class="faq-capsule-question">Are Risk Verifier checks legally compliant and authorized?</h3>
                  <div class="faq-capsule-answer">
                    Yes. All screening activities strictly adhere to Fair Credit Reporting Act (FCRA) provisions in the United States, GDPR regulations in the United Kingdom and European Union, and regional statutory privacy frameworks globally. Where statutory law dictates, signed or digitally authenticated subject authorization is secured prior to processing.
                  </div>
                </div>
                <div class="faq-capsule-toggle" aria-label="Toggle answer">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="6 9 12 15 18 9"></polyline>
                  </svg>
                </div>
              </div>
            </div>

            <!-- FAQ 03 -->
            <div class="faq-timeline-row">
              <div class="faq-timeline-node">
                <div class="faq-timeline-node-inner"></div>
              </div>
              <div class="faq-timeline-connector"></div>

              <div class="faq-capsule-card">
                <div class="faq-capsule-num">03</div>
                <div class="faq-capsule-body">
                  <h3 class="faq-capsule-question">Can Risk Verifier manage high-volume corporate screening?</h3>
                  <div class="faq-capsule-answer">
                    Yes. We partner with multinational corporations, enterprise staffing agencies, and private equity firms handling bulk screening portfolios. We offer batch intake workflows, dedicated account management desks, customized SLA tiers, and centralized billing across our four regional offices.
                  </div>
                </div>
                <div class="faq-capsule-toggle" aria-label="Toggle answer">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="6 9 12 15 18 9"></polyline>
                  </svg>
                </div>
              </div>
            </div>

            <!-- FAQ 04 -->
            <div class="faq-timeline-row">
              <div class="faq-timeline-node">
                <div class="faq-timeline-node-inner"></div>
              </div>
              <div class="faq-timeline-connector"></div>

              <div class="faq-capsule-card">
                <div class="faq-capsule-num">04</div>
                <div class="faq-capsule-body">
                  <h3 class="faq-capsule-question">How is candidate and sensitive corporate data protected?</h3>
                  <div class="faq-capsule-answer">
                    All client and candidate data is encrypted using TLS 1.3 in transit and AES-256 bit encryption at rest. We enforce role-based access restrictions, strict data retention cycles, and automated document redaction to safeguard confidential identifying information.
                  </div>
                </div>
                <div class="faq-capsule-toggle" aria-label="Toggle answer">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="6 9 12 15 18 9"></polyline>
                  </svg>
                </div>
              </div>
            </div>

            <!-- FAQ 05 -->
            <div class="faq-timeline-row">
              <div class="faq-timeline-node">
                <div class="faq-timeline-node-inner"></div>
              </div>
              <div class="faq-timeline-connector"></div>

              <div class="faq-capsule-card">
                <div class="faq-capsule-num">05</div>
                <div class="faq-capsule-body">
                  <h3 class="faq-capsule-question">What is your protocol when adverse or disputed records emerge?</h3>
                  <div class="faq-capsule-answer">
                    Every adverse finding undergoes mandatory secondary analyst corroboration against primary court records to prevent mistaken identity or expunged records from being reported. Detailed case docket identifiers and official source citations are provided to support legally sound dispute resolution or pre-adverse action notice procedures.
                  </div>
                </div>
                <div class="faq-capsule-toggle" aria-label="Toggle answer">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="6 9 12 15 18 9"></polyline>
                  </svg>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>

  </main>

<?php
get_footer();
