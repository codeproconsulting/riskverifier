<?php
/**
 * Template Name: How It Works Page
 *
 * @package RiskVerifier
 */

$is_elementor = false;
if (is_singular()) {
    $pid = get_the_ID();
    if ($pid) {
        if (defined('ELEMENTOR_VERSION') && class_exists('\Elementor\Plugin')) {
            $is_elementor = \Elementor\Plugin::$instance->db->is_built_with_elementor($pid);
        }
        if (!$is_elementor && function_exists('get_post_meta')) {
            $is_elementor = (get_post_meta($pid, '_elementor_edit_mode', true) === 'builder');
        }
    }
}

if ($is_elementor) {
    $page_layout = is_singular() ? get_post_meta(get_the_ID(), '_wp_page_template', true) : '';
    if ($page_layout === 'elementor_canvas') {
        while (have_posts()) { the_post(); the_content(); }
        return;
    }
    get_header();
    echo '<main id="main-content" class="elementor-content-container">';
    while (have_posts()) { the_post(); the_content(); }
    echo '</main>';
    get_footer();
    return;
}

get_header();
?>
  <main>
    <!-- Vector Header Banner -->
    <section class="vector-header-banner">
      <!-- Left Vector Wing -->
      <div class="banner-vector-left" aria-hidden="true">
        <svg viewBox="0 0 340 160" preserveAspectRatio="none" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="cyanGradL" x1="0%" y1="0%" x2="100%" y2="80%">
              <stop offset="0%" stop-color="#00e5ff" />
              <stop offset="50%" stop-color="#00b4d8" />
              <stop offset="100%" stop-color="#0077b6" />
            </linearGradient>
            <linearGradient id="navyGradL" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#05264b" />
              <stop offset="100%" stop-color="#083d77" />
            </linearGradient>
            <filter id="vectorDropShadowL" x="-30%" y="-30%" width="160%" height="160%">
              <feDropShadow dx="5" dy="4" stdDeviation="6" flood-color="#05264b" flood-opacity="0.35" />
            </filter>
            <filter id="bevelShadowL" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="2" dy="2" stdDeviation="3" flood-color="#000000" flood-opacity="0.18" />
            </filter>
          </defs>
          <path d="M 0 28 L 95 38 L 155 160 L 0 160 Z" fill="url(#navyGradL)" />
          <path d="M 70 0 L 105 0 L 132 46 L 95 38 Z" fill="#e2e8f0" filter="url(#bevelShadowL)" />
          <path d="M 0 0 L 85 0 L 132 46 L 180 160 L 155 160 L 95 38 L 0 28 Z" fill="url(#cyanGradL)" filter="url(#vectorDropShadowL)" />
        </svg>
      </div>

      <!-- Center Text Content -->
      <div class="banner-content-box">
        <span class="banner-tagline">5-STEP VERIFICATION METHODOLOGY</span>
        <h1 class="banner-title">HOW IT WORKS</h1>
        <div class="banner-breadcrumb">
          <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
          <span class="sep">/</span>
          <span class="current">How It Works</span>
        </div>
      </div>

      <!-- Right Vector Wing -->
      <div class="banner-vector-right" aria-hidden="true">
        <svg viewBox="0 0 340 160" preserveAspectRatio="none" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="cyanGradR" x1="0%" y1="0%" x2="100%" y2="80%">
              <stop offset="0%" stop-color="#00e5ff" />
              <stop offset="50%" stop-color="#00b4d8" />
              <stop offset="100%" stop-color="#0077b6" />
            </linearGradient>
            <linearGradient id="navyGradR" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#05264b" />
              <stop offset="100%" stop-color="#083d77" />
            </linearGradient>
            <filter id="vectorDropShadowR" x="-30%" y="-30%" width="160%" height="160%">
              <feDropShadow dx="5" dy="4" stdDeviation="6" flood-color="#05264b" flood-opacity="0.35" />
            </filter>
            <filter id="bevelShadowR" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="2" dy="2" stdDeviation="3" flood-color="#000000" flood-opacity="0.18" />
            </filter>
          </defs>
          <path d="M 0 28 L 95 38 L 155 160 L 0 160 Z" fill="url(#navyGradR)" />
          <path d="M 70 0 L 105 0 L 132 46 L 95 38 Z" fill="#e2e8f0" filter="url(#bevelShadowR)" />
          <path d="M 0 0 L 85 0 L 132 46 L 180 160 L 155 160 L 95 38 L 0 28 Z" fill="url(#cyanGradR)" filter="url(#vectorDropShadowR)" />
        </svg>
      </div>
    </section>

    <!-- 5 Steps Breakdown (Alternating Portal Timeline Design) -->
    <section class="section section-white" id="how-it-works">
      <div class="container">
        <div class="svc-header-container">
          <h2 class="svc-main-title">
            <span class="svc-title-light">HOW RISK</span> VERIFICATION WORKS
          </h2>
          <div class="svc-title-underline"></div>
          <p class="svc-header-desc">
            A secure, streamlined 5-step methodology delivering direct-source findings while maintaining strict regulatory compliance and confidentiality.
          </p>
        </div>

        <div class="svc-timeline-container hiw-portal-timeline">
          <div class="svc-timeline-track"></div>

          <!-- Step 01: Submit Your Request (Odd: Content Left, Center Node, Ghost Num Right) -->
          <div class="svc-timeline-row row-odd svc-side-left">
            <div class="svc-timeline-content">
              <span class="svc-turnaround-badge">Step 01 • Intake</span>
              <h3 class="svc-content-title">SUBMIT YOUR REQUEST</h3>
              <p class="svc-content-desc">
                Submit subject details (individual, corporate entity, property, or document). Required authorization and candidate consent are securely collected through encrypted digital workflows.
              </p>
              <div class="showcase-tags-cloud" style="margin-bottom:0; margin-top:12px;">
                <span class="showcase-tag-pill">Encrypted Data Intake</span>
                <span class="showcase-tag-pill">Consent Authorization</span>
              </div>
            </div>

            <div class="svc-timeline-center">
              <div class="svc-connector-line"></div>
              <div class="svc-portal-node">
                <div class="svc-portal-glow"></div>
                <div class="svc-portal-outer-ring"></div>
                <div class="svc-portal-mid-ring"></div>
                <div class="svc-portal-circle">
                  <svg class="svc-portal-icon" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                    <line x1="12" y1="18" x2="12" y2="12"></line>
                    <polyline points="9 15 12 12 15 15"></polyline>
                  </svg>
                </div>
              </div>
            </div>

            <div class="svc-timeline-number">
              <span class="svc-ghost-num">01</span>
            </div>
          </div>

          <!-- Step 02: Verification Scope & Selection (Even: Ghost Num Left, Center Node, Content Right) -->
          <div class="svc-timeline-row row-even svc-side-right">
            <div class="svc-timeline-number">
              <span class="svc-ghost-num">02</span>
            </div>

            <div class="svc-timeline-center">
              <div class="svc-connector-line"></div>
              <div class="svc-portal-node">
                <div class="svc-portal-glow"></div>
                <div class="svc-portal-outer-ring"></div>
                <div class="svc-portal-mid-ring"></div>
                <div class="svc-portal-circle">
                  <svg class="svc-portal-icon" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M9 6h11"></path>
                    <path d="M9 12h11"></path>
                    <path d="M9 18h11"></path>
                    <polyline points="4 6 5.5 7.5 8 5"></polyline>
                    <polyline points="4 12 5.5 13.5 8 11"></polyline>
                    <polyline points="4 18 5.5 19.5 8 17"></polyline>
                  </svg>
                </div>
              </div>
            </div>

            <div class="svc-timeline-content">
              <span class="svc-turnaround-badge">Step 02 • Scope</span>
              <h3 class="svc-content-title">SELECT VERIFICATION SERVICES</h3>
              <p class="svc-content-desc">
                Configure screening dimensions aligned with your compliance risk profile—spanning criminal, civil litigation, credit solvency, vital records, credentials, or deep corporate due diligence.
              </p>
              <div class="showcase-tags-cloud" style="margin-bottom:0; margin-top:12px;">
                <span class="showcase-tag-pill">12 Specialized Vectors</span>
                <span class="showcase-tag-pill">Custom Risk Profiling</span>
              </div>
            </div>
          </div>

          <!-- Step 03: Direct Investigation & Cross-Referencing (Odd) -->
          <div class="svc-timeline-row row-odd svc-side-left">
            <div class="svc-timeline-content">
              <span class="svc-turnaround-badge">Step 03 • Investigation</span>
              <h3 class="svc-content-title">RESEARCH, VERIFY & CROSS-REFERENCE</h3>
              <p class="svc-content-desc">
                Our vetted analysts query authorized government registers, law enforcement repositories, court dockets, credit bureaus, and global sanctions lists to extract factual, untampered intelligence.
              </p>
              <div class="showcase-tags-cloud" style="margin-bottom:0; margin-top:12px;">
                <span class="showcase-tag-pill">Direct Source Archives</span>
                <span class="showcase-tag-pill">Global Sanctions & PEP</span>
              </div>
            </div>

            <div class="svc-timeline-center">
              <div class="svc-connector-line"></div>
              <div class="svc-portal-node">
                <div class="svc-portal-glow"></div>
                <div class="svc-portal-outer-ring"></div>
                <div class="svc-portal-mid-ring"></div>
                <div class="svc-portal-circle">
                  <svg class="svc-portal-icon" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    <polyline points="8 11 10.5 13.5 14.5 9.5"></polyline>
                  </svg>
                </div>
              </div>
            </div>

            <div class="svc-timeline-number">
              <span class="svc-ghost-num">03</span>
            </div>
          </div>

          <!-- Step 04: Consolidated Intelligence Report (Even) -->
          <div class="svc-timeline-row row-even svc-side-right">
            <div class="svc-timeline-number">
              <span class="svc-ghost-num">04</span>
            </div>

            <div class="svc-timeline-center">
              <div class="svc-connector-line"></div>
              <div class="svc-portal-node">
                <div class="svc-portal-glow"></div>
                <div class="svc-portal-outer-ring"></div>
                <div class="svc-portal-mid-ring"></div>
                <div class="svc-portal-circle">
                  <svg class="svc-portal-icon" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
                    <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
                    <path d="M9 14l2 2 4-4"></path>
                  </svg>
                </div>
              </div>
            </div>

            <div class="svc-timeline-content">
              <span class="svc-turnaround-badge">Step 04 • Reporting</span>
              <h3 class="svc-content-title">RECEIVE CONSOLIDATED REPORT</h3>
              <p class="svc-content-desc">
                Receive an executive, evidentiary dossier featuring verified records, official timestamps, clarity indexes, and risk categorization—enabling swift assessment without data ambiguity.
              </p>
              <div class="showcase-tags-cloud" style="margin-bottom:0; margin-top:12px;">
                <span class="showcase-tag-pill">Evidentiary Documentation</span>
                <span class="showcase-tag-pill">Executive Risk Index</span>
              </div>
            </div>
          </div>

          <!-- Step 05: Confident Decision Making (Odd) -->
          <div class="svc-timeline-row row-odd svc-side-left">
            <div class="svc-timeline-content">
              <span class="svc-turnaround-badge">Step 05 • Decision</span>
              <h3 class="svc-content-title">MAKE CONFIDENT DECISIONS</h3>
              <p class="svc-content-desc">
                Leverage tamper-proof intelligence to support safe executive hiring, robust vendor onboarding, commercial transaction due diligence, and regulatory compliance protection.
              </p>
              <div class="showcase-tags-cloud" style="margin-bottom:0; margin-top:12px;">
                <span class="showcase-tag-pill">Protected Governance</span>
                <span class="showcase-tag-pill">Total Risk Mitigation</span>
              </div>
            </div>

            <div class="svc-timeline-center">
              <div class="svc-connector-line"></div>
              <div class="svc-portal-node">
                <div class="svc-portal-glow"></div>
                <div class="svc-portal-outer-ring"></div>
                <div class="svc-portal-mid-ring"></div>
                <div class="svc-portal-circle">
                  <svg class="svc-portal-icon" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                    <polyline points="9 12 11 14 15 10"></polyline>
                  </svg>
                </div>
              </div>
            </div>

            <div class="svc-timeline-number">
              <span class="svc-ghost-num">05</span>
            </div>
          </div>

        </div>

        <div style="margin-top: 40px; text-align: center;">
          <div style="display: inline-block; padding: 14px 26px; background-color: #ffffff; border: 1.5px solid #083d77; border-radius: 12px; font-size: 0.9rem; color: #083d77; font-weight: 700; box-shadow: 0 4px 14px rgba(8,61,119,0.06);">
            ⚡ <strong>Turnaround SLA:</strong> Standard background verification delivered in <strong>24 to 72 hours</strong>. Complex global due diligence in 2 to 7 business days.
          </div>
        </div>
      </div>
    </section>
  </main>

<?php
get_footer();
